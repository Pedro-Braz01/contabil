// ── Alíquotas padrão ──────────────────────────────────────────────────────────
const DEFAULTS = { pis: 0.65, cofins: 3.00, irrf: 1.50, csll: 1.00 };

// ── Utilidades ────────────────────────────────────────────────────────────────
function formatarMoeda(valor) {
    return valor.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}

function formatarNumero(valor) {
    // Formata sem símbolo, ex: "15,00"
    return valor.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function formatarCnpj(s) {
    return s.replace(/^(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})$/, "$1.$2.$3/$4-$5");
}

function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

// ── Carregar alíquotas salvas ─────────────────────────────────────────────────
async function carregarAliquotas() {
    const data = await chrome.storage.local.get("aliquotas");
    return Object.assign({}, DEFAULTS, data.aliquotas || {});
}

// ── Inicializar página de configurações ───────────────────────────────────────
async function inicializarConfig() {
    const ali = await carregarAliquotas();

    document.getElementById("cfg-pis").value    = ali.pis;
    document.getElementById("cfg-cofins").value = ali.cofins;
    document.getElementById("cfg-irrf").value   = ali.irrf;
    document.getElementById("cfg-csll").value   = ali.csll;

    atualizarBadges(ali);
    carregarLicencaConfig(); // carrega dados da licença na aba config
}

function atualizarBadges(ali) {
    document.getElementById("badge-pis").textContent    = ali.pis.toFixed(2).replace(".", ",") + "%";
    document.getElementById("badge-cofins").textContent = ali.cofins.toFixed(2).replace(".", ",") + "%";
    document.getElementById("badge-irrf").textContent   = ali.irrf.toFixed(2).replace(".", ",") + "%";
    document.getElementById("badge-csll").textContent   = ali.csll.toFixed(2).replace(".", ",") + "%";
}

// ── Tabs ──────────────────────────────────────────────────────────────────────
document.querySelectorAll(".tab-btn").forEach(btn => {
    btn.addEventListener("click", () => {
        document.querySelectorAll(".tab-btn").forEach(b => b.classList.remove("active"));
        document.querySelectorAll(".page").forEach(p => p.classList.remove("active"));
        btn.classList.add("active");
        document.getElementById("tab-" + btn.dataset.tab).classList.add("active");
        if (btn.dataset.tab === "config") inicializarConfig();
    });
});

// ── Formatar campo de valor enquanto digita ───────────────────────────────────
document.getElementById("valor").addEventListener("input", function (e) {
    let valor = e.target.value.replace(/\D/g, "");
    valor = (valor / 100).toFixed(2) + "";
    valor = valor.replace(".", ",");
    valor = valor.replace(/\B(?=(\d{3})+(?!\d))/g, ".");
    e.target.value = "R$ " + valor;
});

// ── Copiar valor para clipboard ───────────────────────────────────────────────
async function copiarValor(valorNumerico, elemento) {
    const texto = formatarNumero(valorNumerico); // ex: "15,00"
    try {
        await navigator.clipboard.writeText(texto);
    } catch (_) {}

    // Flash visual
    elemento.classList.add("copied-flash");
    const original = elemento.querySelector(".imposto-valor") || elemento;
    const nomeEl   = elemento.querySelector(".imposto-nome");
    const nomeBkp  = nomeEl ? nomeEl.textContent : null;

    if (nomeEl) nomeEl.textContent = "✔ Copiado!";
    setTimeout(() => {
        elemento.classList.remove("copied-flash");
        if (nomeEl && nomeBkp) nomeEl.textContent = nomeBkp;
    }, 800);
}

// ── Buscar CNPJ na aba ────────────────────────────────────────────────────────
async function buscarCnpjNaAba() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    try {
        const results = await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            func: () => {
                const regex = /\b\d{2}\.?\d{3}\.?\d{3}[\/]?\d{4}[-]?\d{2}\b/g;
                const texto = document.body.innerText || "";
                const matches = texto.match(regex);
                if (!matches) return null;
                const validos = matches.filter(m => m.replace(/\D/g, "").length === 14);
                return validos.length > 0 ? validos[0] : null;
            }
        });
        if (results && results[0] && results[0].result) {
            return results[0].result.replace(/\D/g, "");
        }
    } catch (err) {
        console.warn("Não foi possível ler a aba:", err.message);
    }
    return null;
}

// ── Botão Consultar Regime ────────────────────────────────────────────────────
document.getElementById("abrirSite").addEventListener("click", async () => {
    const btn    = document.getElementById("abrirSite");
    const status = document.getElementById("statusCnpj");

    btn.disabled = true;
    status.className = "status";
    status.textContent = "Buscando CNPJ na página...";

    const cnpjEncontrado = await buscarCnpjNaAba();

    if (cnpjEncontrado) {
        try { await navigator.clipboard.writeText(cnpjEncontrado); } catch (_) {}
        await chrome.storage.local.set({ cnpjParaConsulta: cnpjEncontrado, cnpjTimestamp: Date.now() });
        status.className = "status ok";
        status.textContent = `✔ CNPJ: ${formatarCnpj(cnpjEncontrado)}`;
        await delay(3000);
        chrome.tabs.create({ url: "https://www8.receita.fazenda.gov.br/SimplesNacional/aplicacoes.aspx?id=21" });
    } else {
        await chrome.storage.local.remove("cnpjParaConsulta");
        status.className = "status erro";
        status.textContent = "Nenhum CNPJ encontrado. Abrindo em 3s...";
        await delay(3000);
        chrome.tabs.create({ url: "https://www8.receita.fazenda.gov.br/SimplesNacional/aplicacoes.aspx?id=21" });
    }
    btn.disabled = false;
});

// ── Botão Consultar CNPJ ──────────────────────────────────────────────────────
document.getElementById("consultarCnpj").addEventListener("click", async () => {
    const btn    = document.getElementById("consultarCnpj");
    const status = document.getElementById("statusCnpj");

    btn.disabled = true;
    status.className = "status";
    status.textContent = "Buscando CNPJ na página...";

    const cnpjEncontrado = await buscarCnpjNaAba();

    if (cnpjEncontrado) {
        try { await navigator.clipboard.writeText(cnpjEncontrado); } catch (_) {}
        status.className = "status ok";
        status.textContent = `✔ CNPJ: ${formatarCnpj(cnpjEncontrado)}`;
    } else {
        status.className = "status erro";
        status.textContent = "Nenhum CNPJ encontrado. Abrindo em 3s...";
    }

    await delay(3000);
    chrome.tabs.create({
        url: `https://solucoes.receita.fazenda.gov.br/servicos/cnpjreva/Cnpjreva_Solicitacao.asp?cnpj=${cnpjEncontrado || ""}`
    });
    btn.disabled = false;
});

// ── Botão Calcular ────────────────────────────────────────────────────────────
document.getElementById("calcular").addEventListener("click", async () => {
    const input     = document.getElementById("valor").value;
    const numero    = parseFloat(input.replace(/\D/g, "")) / 100;
    const resultado = document.getElementById("resultado");

    if (isNaN(numero) || numero <= 0) {
        resultado.innerHTML = `<div class="card" style="color:#b91c1c;font-size:13px;text-align:center;">Informe um valor válido.</div>`;
        return;
    }

    const ali = await carregarAliquotas();

    const pis    = numero * (ali.pis    / 100);
    const cofins = numero * (ali.cofins / 100);
    const irrf   = numero * (ali.irrf   / 100);
    const csll   = numero * (ali.csll   / 100);

    const impostos = [
        { nome: "PIS",    valor: pis,    grupo: "pcc" },
        { nome: "COFINS", valor: cofins, grupo: "pcc" },
        { nome: "CSLL",   valor: csll,   grupo: "pcc" },
        { nome: "IRRF",   valor: irrf,   grupo: "irrf" },
    ];

    const somaPcc  = pis + cofins + csll;
    const exibirPcc  = somaPcc >= 10;
    const exibirIrrf = irrf >= 10;

    let totalImpostos = 0;
    let linhas = [];

    for (const imp of impostos) {
        const exibir = (imp.grupo === "pcc" && exibirPcc) || (imp.grupo === "irrf" && exibirIrrf);
        if (!exibir) continue;
        totalImpostos += imp.valor;
        linhas.push(imp);
    }

    if (linhas.length === 0) {
        resultado.innerHTML = `<div class="card" style="font-size:13px;color:#64748b;text-align:center;padding:12px;">Nenhum imposto a reter<br><small>(todos abaixo de R$ 10,00)</small></div>`;
        return;
    }

    const valorLiquido = numero - totalImpostos;

    // Monta HTML do card de resultado
    const card = document.createElement("div");
    card.className = "card";

    const hint = document.createElement("div");
    hint.className = "copy-hint";
    hint.textContent = "Clique em qualquer linha para copiar o valor";
    card.appendChild(hint);

    for (const imp of linhas) {
        const linha = document.createElement("div");
        linha.className = "imposto-linha";
        linha.innerHTML = `<span class="imposto-nome">${imp.nome}</span><span class="imposto-valor">${formatarMoeda(imp.valor)}</span>`;
        linha.addEventListener("click", () => copiarValor(imp.valor, linha));
        card.appendChild(linha);
    }

    const totalEl = document.createElement("div");
    totalEl.className = "total-linha";
    totalEl.innerHTML = `<span>Líquido</span><span>${formatarMoeda(valorLiquido)}</span>`;
    totalEl.addEventListener("click", () => {
        // Copiar valor líquido
        navigator.clipboard.writeText(formatarNumero(valorLiquido)).catch(() => {});
        const span = totalEl.querySelector("span:first-child");
        const bkp = span.textContent;
        span.textContent = "✔ Copiado!";
        setTimeout(() => span.textContent = bkp, 800);
    });
    card.appendChild(totalEl);

    resultado.innerHTML = "";
    resultado.appendChild(card);
});

// ── Salvar configurações ──────────────────────────────────────────────────────
document.getElementById("salvarConfig").addEventListener("click", async () => {
    const ali = {
        pis:    parseFloat(document.getElementById("cfg-pis").value)    || DEFAULTS.pis,
        cofins: parseFloat(document.getElementById("cfg-cofins").value) || DEFAULTS.cofins,
        irrf:   parseFloat(document.getElementById("cfg-irrf").value)   || DEFAULTS.irrf,
        csll:   parseFloat(document.getElementById("cfg-csll").value)   || DEFAULTS.csll,
    };

    await chrome.storage.local.set({ aliquotas: ali });
    atualizarBadges(ali);

    const msg = document.getElementById("saveMsg");
    msg.classList.add("show");
    setTimeout(() => msg.classList.remove("show"), 2500);
});

// ── Restaurar padrões ─────────────────────────────────────────────────────────
document.getElementById("resetarConfig").addEventListener("click", async () => {
    await chrome.storage.local.remove("aliquotas");
    document.getElementById("cfg-pis").value    = DEFAULTS.pis;
    document.getElementById("cfg-cofins").value = DEFAULTS.cofins;
    document.getElementById("cfg-irrf").value   = DEFAULTS.irrf;
    document.getElementById("cfg-csll").value   = DEFAULTS.csll;
    atualizarBadges(DEFAULTS);

    const msg = document.getElementById("saveMsg");
    msg.textContent = "✔ Padrões restaurados!";
    msg.classList.add("show");
    setTimeout(() => { msg.classList.remove("show"); msg.textContent = "✔ Configurações salvas!"; }, 2500);
});

// ── Licença na Config ─────────────────────────────────────────────────────────

// Formata chave enquanto digita
const cfgLicChave = document.getElementById("cfg-lic-chave");
if (cfgLicChave) {
    cfgLicChave.addEventListener("input", function () {
        let v = this.value.toUpperCase().replace(/[^A-Z0-9]/g, '');
        if (v.startsWith('FISCAL')) {
            const prefixo = v.substring(0, 6);
            const resto = v.substring(6).replace(/(.{4})/g, '$1-').replace(/-$/, '');
            this.value = resto ? prefixo + '-' + resto : prefixo;
        }
    });
}

// Carrega dados da licença na aba config
function carregarLicencaConfig() {
    chrome.runtime.sendMessage({ action: 'getLicenseInfo' }, (result) => {
        if (chrome.runtime.lastError) return;
        if (!result) return;

        const infoBox  = document.getElementById("licInfoBox");
        const elStatus = document.getElementById("licStatus");
        const elPlano  = document.getElementById("licPlano");
        const elExpira = document.getElementById("licExpira");
        const elExpWrap = document.getElementById("licExpiraWrap");
        const inputChave = document.getElementById("cfg-lic-chave");
        const inputEmail = document.getElementById("cfg-lic-email");

        if (result.chave) inputChave.value = result.chave;
        if (result.email) inputEmail.value = result.email;

        if (result.ok) {
            infoBox.style.display = 'block';
            elStatus.textContent = '✅ Ativa';
            elStatus.style.color = '#15803d';
            elPlano.textContent = result.plano || 'ATIVO';
            if (result.diasRestantes != null) {
                elExpWrap.style.display = '';
                elExpira.textContent = result.diasRestantes + ' dia(s) — ' + (result.expira || '');
                if (result.diasRestantes <= 7) elExpira.style.color = '#dc2626';
            } else {
                elExpWrap.style.display = '';
                elExpira.textContent = 'Sem expiração';
            }
        } else if (result.chave) {
            infoBox.style.display = 'block';
            elStatus.textContent = '❌ Inválida';
            elStatus.style.color = '#dc2626';
            elPlano.textContent = '—';
            elExpWrap.style.display = 'none';
        }
    });
}

// Salvar licença pela config
document.getElementById("salvarLicenca").addEventListener("click", async () => {
    const chave = document.getElementById("cfg-lic-chave").value.trim();
    const email = document.getElementById("cfg-lic-email").value.trim();
    const msgEl = document.getElementById("saveMsgLic");

    if (!chave || !email) {
        msgEl.textContent = "❌ Preencha chave e e-mail!";
        msgEl.style.color = "#dc2626";
        msgEl.classList.add("show");
        setTimeout(() => { msgEl.classList.remove("show"); msgEl.style.color = "#15803d"; msgEl.textContent = "✔ Licença salva!"; }, 3000);
        return;
    }

    const btnSalvar = document.getElementById("salvarLicenca");
    btnSalvar.disabled = true;
    btnSalvar.textContent = "Verificando...";

    chrome.runtime.sendMessage({ action: 'salvarLicenca', chave, email }, (result) => {
        btnSalvar.disabled = false;
        btnSalvar.textContent = "Salvar Licença";

        if (chrome.runtime.lastError) {
            msgEl.textContent = "❌ Erro de comunicação";
            msgEl.style.color = "#dc2626";
        } else if (result && result.ok) {
            msgEl.textContent = "✔ Licença salva e verificada!";
            msgEl.style.color = "#15803d";
            carregarLicencaConfig();
        } else {
            msgEl.textContent = "❌ " + (result?.msg || "Licença inválida");
            msgEl.style.color = "#dc2626";
        }

        msgEl.classList.add("show");
        setTimeout(() => { msgEl.classList.remove("show"); msgEl.style.color = "#15803d"; msgEl.textContent = "✔ Licença salva!"; }, 3500);
    });
});
