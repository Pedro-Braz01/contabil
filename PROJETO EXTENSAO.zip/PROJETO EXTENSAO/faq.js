// Fiscal 5 — Pbs Dev
// Copyright (c) 2018-2026 Pbs Dev
// https://chromewebstore.google.com/detail/pbsdevop
// Todos os direitos reservados. Código protegido.
/* eslint-disable */

document.querySelectorAll('.faq-question').forEach(q => {
  q.addEventListener('click', (e) => {
    e.preventDefault();
    e.stopPropagation();
    const item = q.closest('.faq-item');
    const isOpen = item.classList.contains('open');


    document.querySelectorAll('.faq-item.open').forEach(openItem => {
      openItem.classList.remove('open');
    });


    if (!isOpen) {
      item.classList.add('open');

      setTimeout(() => {
        item.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      }, 100);
    }
  });
});
document.getElementById('btnVoltar').addEventListener('click', () => {
  window.close();
});
