// ============================================================
// FISCAL - SISTEMA DE CONTROLE DE LICENÇAS
// Google Apps Script — Deploy como Web App
// Copyright (c) 2018-2026 Pbs Devop
// ============================================================

// ── CONFIGURAÇÕES ────────────────────────────────────────────
const CONFIG = {
  SHEET_ID:        '1kJFYxwR_9awNlqgqbQpytpY6K-caeroLiwgaavdzYR0',
  ABA_LICENCAS:    'Licenças',
  ABA_LOG:         'Log de Acessos',
  CHAVE_SECRETA:   'FISCAL_PBS_2026_SECURE',   // ← troque por algo mais seguro
  CACHE_SEGUNDOS:  300,                         // 5 min de cache por licença
  MAX_REQUESTS_DIA: 500,                        // limite por licença/dia (anti-abuso)
};

// ── COLUNAS DA ABA "Licenças" ────────────────────────────────
// A  = Chave
// B  = Email
// C  = Nome/Razão Social
// D  = Status       (ATIVA | SUSPENSA | EXPIRADA | BLOQUEADA)
// E  = Plano        (BASICO | PRO | ENTERPRISE)
// F  = Data Início  (dd/MM/yyyy)
// G  = Data Expira  (dd/MM/yyyy ou vazio = sem expiração)
// H  = Dispositivos (max simultâneos; 0 = ilimitado)
// I  = Versão Min   (ex: 5.0 — versões abaixo são bloqueadas)
// J  = Observações
// K  = Criado em    (timestamp automático)
// L  = Último Acesso (timestamp — atualizado a cada checagem)
// M  = Total Acessos (contador)

// ── COLUNAS DA ABA "Log de Acessos" ─────────────────────────
// A = Timestamp
// B = Chave
// C = Email
// D = Versão da extensão
// E = Resultado (OK | ERRO | BLOQUEADA)
// F = Motivo
// G = IP / User-Agent (headers do request)

// ============================================================
// ENTRY POINT — doPost (chamado pela extensão)
// ============================================================
function doPost(e) {
  return handleRequest(e);
}

function doGet(e) {
  return handleRequest(e);
}

function handleRequest(e) {
  // CORS — permite chamadas da extensão Chrome
  const output = ContentService.createTextOutput();
  output.setMimeType(ContentService.MimeType.JSON);

  try {
    // Aceita tanto POST (body JSON) quanto GET (query params)
    let params = {};
    if (e.postData && e.postData.contents) {
      try { params = JSON.parse(e.postData.contents); } catch (_) {}
    }
    // Query params sobrescrevem (GET ou fallback)
    if (e.parameter) {
      Object.assign(params, e.parameter);
    }

    const action = params.action || 'verificar';

    // ── Verifica assinatura ──────────────────────────────────
    // Para evitar chamadas diretas na URL da planilha,
    // a extensão envia um hash HMAC-like simples.
    // Aqui fazemos uma validação básica de token.
    if (!validarToken(params.token, params.chave)) {
      return jsonResponse(output, { ok: false, erro: 'TOKEN_INVALIDO', msg: 'Requisição não autorizada.' });
    }

    switch (action) {
      case 'verificar':
        return jsonResponse(output, verificarLicenca(params));
      case 'ativar':
        return jsonResponse(output, ativarLicenca(params));
      case 'info':
        return jsonResponse(output, infoLicenca(params));
      default:
        return jsonResponse(output, { ok: false, erro: 'ACAO_INVALIDA' });
    }
  } catch (err) {
    Logger.log('ERRO handleRequest: ' + err.message + '\n' + err.stack);
    return jsonResponse(output, { ok: false, erro: 'ERRO_INTERNO', msg: err.message });
  }
}

// ============================================================
// VERIFICAR LICENÇA — ação principal chamada pela extensão
// ============================================================
function verificarLicenca(params) {
  const chave   = String(params.chave   || '').trim().toUpperCase();
  const email   = String(params.email   || '').trim().toLowerCase();
  const versao  = String(params.versao  || '0').trim();

  if (!chave) return { ok: false, erro: 'CHAVE_VAZIA', msg: 'Informe a chave de licença.' };

  // Tenta cache (evita leitura de planilha a cada request)
  const cache     = CacheService.getScriptCache();
  const cacheKey  = 'lic_' + chave;
  const cached    = cache.get(cacheKey);

  let licenca;
  if (cached) {
    try { licenca = JSON.parse(cached); } catch (_) { /* ignora cache corrompido */ }
  }

  if (!licenca) {
    licenca = buscarLicenca(chave);
    if (licenca) {
      cache.put(cacheKey, JSON.stringify(licenca), CONFIG.CACHE_SEGUNDOS);
    }
  }

  // Chave não encontrada
  if (!licenca) {
    registrarLog(chave, email, versao, 'ERRO', 'CHAVE_NAO_ENCONTRADA');
    return { ok: false, erro: 'CHAVE_INVALIDA', msg: 'Licença não encontrada. Verifique a chave informada.' };
  }

  // ── Verificações ─────────────────────────────────────────
  const agora = new Date();

  // 1. Status
  if (licenca.status !== 'ATIVA') {
    const msgs = {
      SUSPENSA:  'Sua licença está suspensa. Entre em contato com o suporte.',
      EXPIRADA:  'Sua licença expirou. Renove para continuar usando.',
      BLOQUEADA: 'Sua licença foi bloqueada por uso indevido.',
    };
    registrarLog(chave, email, versao, 'BLOQUEADA', licenca.status);
    return { ok: false, erro: licenca.status, msg: msgs[licenca.status] || 'Licença inativa.' };
  }

  // 2. Expiração por data
  if (licenca.dataExpira) {
    const expira = parseDateBR(licenca.dataExpira);
    if (expira && agora > expira) {
      // Atualiza status para EXPIRADA na planilha
      atualizarStatus(chave, 'EXPIRADA');
      cache.remove(cacheKey);
      registrarLog(chave, email, versao, 'BLOQUEADA', 'DATA_EXPIRADA');
      return { ok: false, erro: 'EXPIRADA', msg: 'Sua licença expirou em ' + licenca.dataExpira + '. Renove para continuar usando.' };
    }
  }

  // 3. Versão mínima
  if (licenca.versaoMin && versao) {
    if (compararVersao(versao, licenca.versaoMin) < 0) {
      registrarLog(chave, email, versao, 'BLOQUEADA', 'VERSAO_DESATUALIZADA');
      return { ok: false, erro: 'VERSAO_DESATUALIZADA', msg: 'Atualize a extensão para a versão ' + licenca.versaoMin + ' ou superior.' };
    }
  }

  // 4. Verifica e-mail se fornecido e se licença tem e-mail cadastrado
  if (licenca.email && email && licenca.email !== email) {
    registrarLog(chave, email, versao, 'BLOQUEADA', 'EMAIL_DIVERGENTE');
    return { ok: false, erro: 'EMAIL_DIVERGENTE', msg: 'Esta licença está vinculada a outro e-mail.' };
  }

  // ── Tudo OK ──────────────────────────────────────────────
  // Atualiza último acesso (fora do cache — escrita assíncrona)
  atualizarUltimoAcesso(chave);
  registrarLog(chave, email, versao, 'OK', 'AUTORIZADO');

  // Calcula dias restantes (se tiver expiração)
  let diasRestantes = null;
  if (licenca.dataExpira) {
    const expira = parseDateBR(licenca.dataExpira);
    if (expira) {
      diasRestantes = Math.ceil((expira - agora) / (1000 * 60 * 60 * 24));
    }
  }

  return {
    ok:           true,
    plano:        licenca.plano,
    nome:         licenca.nome,
    diasRestantes: diasRestantes,
    expira:       licenca.dataExpira || null,
    versaoMin:    licenca.versaoMin  || null,
    msg:          'Licença válida.'
  };
}

// ============================================================
// ATIVAR LICENÇA — vincula email à chave na 1ª ativação
// ============================================================
function ativarLicenca(params) {
  const chave  = String(params.chave  || '').trim().toUpperCase();
  const email  = String(params.email  || '').trim().toLowerCase();
  const nome   = String(params.nome   || '').trim();

  if (!chave || !email) {
    return { ok: false, erro: 'PARAMETROS_INCOMPLETOS', msg: 'Chave e e-mail são obrigatórios.' };
  }

  const licenca = buscarLicenca(chave);
  if (!licenca) {
    return { ok: false, erro: 'CHAVE_INVALIDA', msg: 'Chave não encontrada.' };
  }

  if (licenca.status !== 'ATIVA') {
    return { ok: false, erro: licenca.status, msg: 'Licença inativa ou bloqueada.' };
  }

  // Se já tem e-mail vinculado, verifica se é o mesmo
  if (licenca.email && licenca.email !== email) {
    return { ok: false, erro: 'CHAVE_JA_VINCULADA', msg: 'Esta chave já está vinculada a outro e-mail.' };
  }

  // Vincula o email (1ª ativação)
  if (!licenca.email) {
    const ss    = SpreadsheetApp.openById(CONFIG.SHEET_ID);
    const aba   = ss.getSheetByName(CONFIG.ABA_LICENCAS);
    const dados = aba.getDataRange().getValues();

    for (let i = 1; i < dados.length; i++) {
      if (String(dados[i][0]).trim().toUpperCase() === chave) {
        aba.getRange(i + 1, 2).setValue(email);       // col B = Email
        if (nome && !dados[i][2]) {
          aba.getRange(i + 1, 3).setValue(nome);       // col C = Nome
        }
        break;
      }
    }

    // Invalida cache
    CacheService.getScriptCache().remove('lic_' + chave);
  }

  registrarLog(chave, email, params.versao || '', 'OK', 'ATIVACAO');
  return { ok: true, msg: 'Licença ativada com sucesso!' };
}

// ============================================================
// INFO LICENÇA — retorna dados básicos para exibir na extensão
// ============================================================
function infoLicenca(params) {
  const result = verificarLicenca(params);
  return result;
}

// ============================================================
// FUNÇÕES AUXILIARES
// ============================================================

function buscarLicenca(chave) {
  try {
    const ss    = SpreadsheetApp.openById(CONFIG.SHEET_ID);
    const aba   = ss.getSheetByName(CONFIG.ABA_LICENCAS);
    const dados = aba.getDataRange().getValues();

    for (let i = 1; i < dados.length; i++) {
      const row = dados[i];
      if (String(row[0]).trim().toUpperCase() === chave) {
        return {
          chave:      String(row[0]).trim().toUpperCase(),
          email:      String(row[1]).trim().toLowerCase(),
          nome:       String(row[2]).trim(),
          status:     String(row[3]).trim().toUpperCase() || 'ATIVA',
          plano:      String(row[4]).trim().toUpperCase() || 'BASICO',
          dataInicio: String(row[5]).trim(),
          dataExpira: String(row[6]).trim(),
          dispositivos: parseInt(row[7]) || 0,
          versaoMin:  String(row[8]).trim(),
          obs:        String(row[9]).trim(),
          rowIndex:   i + 1,
        };
      }
    }
  } catch (err) {
    Logger.log('Erro buscarLicenca: ' + err.message);
  }
  return null;
}

function atualizarStatus(chave, novoStatus) {
  try {
    const ss    = SpreadsheetApp.openById(CONFIG.SHEET_ID);
    const aba   = ss.getSheetByName(CONFIG.ABA_LICENCAS);
    const dados = aba.getDataRange().getValues();
    for (let i = 1; i < dados.length; i++) {
      if (String(dados[i][0]).trim().toUpperCase() === chave) {
        aba.getRange(i + 1, 4).setValue(novoStatus); // col D
        break;
      }
    }
  } catch (err) {
    Logger.log('Erro atualizarStatus: ' + err.message);
  }
}

function atualizarUltimoAcesso(chave) {
  try {
    const ss    = SpreadsheetApp.openById(CONFIG.SHEET_ID);
    const aba   = ss.getSheetByName(CONFIG.ABA_LICENCAS);
    const dados = aba.getDataRange().getValues();
    const agora = new Date();
    for (let i = 1; i < dados.length; i++) {
      if (String(dados[i][0]).trim().toUpperCase() === chave) {
        aba.getRange(i + 1, 12).setValue(agora);          // col L = Último Acesso
        const total = parseInt(dados[i][12]) || 0;
        aba.getRange(i + 1, 13).setValue(total + 1);      // col M = Total Acessos
        break;
      }
    }
  } catch (err) {
    Logger.log('Erro atualizarUltimoAcesso: ' + err.message);
  }
}

function registrarLog(chave, email, versao, resultado, motivo) {
  try {
    const ss  = SpreadsheetApp.openById(CONFIG.SHEET_ID);
    const log = ss.getSheetByName(CONFIG.ABA_LOG);
    log.appendRow([
      new Date(),
      chave,
      email,
      versao,
      resultado,
      motivo,
      Session.getActiveUser().getEmail() || ''
    ]);
  } catch (err) {
    Logger.log('Erro registrarLog: ' + err.message);
  }
}

// Validação simples de token
// A extensão envia: SHA256(chave + CHAVE_SECRETA) — aqui simulamos com um hash básico
// Para produção, use Utilities.computeDigest com HMAC-SHA256
function validarToken(token, chave) {
  if (!token || !chave) return false;

  // Gera o token esperado
  const dados   = String(chave).trim().toUpperCase() + CONFIG.CHAVE_SECRETA;
  const bytes   = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, dados);
  const esperado = bytes.map(b => ('0' + (b & 0xFF).toString(16)).slice(-2)).join('').substring(0, 32);

  return String(token).toLowerCase() === esperado.toLowerCase();
}

// Compara versões: retorna -1, 0 ou 1
function compararVersao(v1, v2) {
  const p1 = String(v1).split('.').map(Number);
  const p2 = String(v2).split('.').map(Number);
  const len = Math.max(p1.length, p2.length);
  for (let i = 0; i < len; i++) {
    const n1 = p1[i] || 0;
    const n2 = p2[i] || 0;
    if (n1 < n2) return -1;
    if (n1 > n2) return  1;
  }
  return 0;
}

// Converte dd/MM/yyyy para Date
function parseDateBR(str) {
  if (!str) return null;
  const parts = str.split('/');
  if (parts.length !== 3) return null;
  const d = parseInt(parts[0]);
  const m = parseInt(parts[1]) - 1;
  const y = parseInt(parts[2]);
  const dt = new Date(y, m, d);
  return isNaN(dt.getTime()) ? null : dt;
}

function jsonResponse(output, data) {
  output.setContent(JSON.stringify(data));
  return output;
}

// ============================================================
// SETUP INICIAL — Rode esta função UMA VEZ para criar as abas
// ============================================================
function setupPlanilha() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();

  // ── Aba Licenças ─────────────────────────────────────────
  let abaLic = ss.getSheetByName(CONFIG.ABA_LICENCAS);
  if (!abaLic) {
    abaLic = ss.insertSheet(CONFIG.ABA_LICENCAS);
  }

  const headerLic = [
    'Chave', 'Email', 'Nome/Empresa', 'Status', 'Plano',
    'Data Início', 'Data Expira', 'Dispositivos', 'Versão Min',
    'Observações', 'Criado em', 'Último Acesso', 'Total Acessos'
  ];
  abaLic.getRange(1, 1, 1, headerLic.length).setValues([headerLic]);

  // Formatação do cabeçalho
  const headerRange = abaLic.getRange(1, 1, 1, headerLic.length);
  headerRange.setBackground('#1a1f2e');
  headerRange.setFontColor('#ffffff');
  headerRange.setFontWeight('bold');
  headerRange.setFontSize(11);

  // Larguras
  abaLic.setColumnWidth(1, 220);  // Chave
  abaLic.setColumnWidth(2, 200);  // Email
  abaLic.setColumnWidth(3, 180);  // Nome
  abaLic.setColumnWidth(4, 100);  // Status
  abaLic.setColumnWidth(5, 100);  // Plano
  abaLic.setColumnWidth(6, 110);  // Data Início
  abaLic.setColumnWidth(7, 110);  // Data Expira
  abaLic.setColumnWidth(8, 110);  // Dispositivos
  abaLic.setColumnWidth(9, 100);  // Versão Min
  abaLic.setColumnWidth(10, 200); // Obs
  abaLic.setColumnWidth(11, 140); // Criado em
  abaLic.setColumnWidth(12, 140); // Último Acesso
  abaLic.setColumnWidth(13, 110); // Total Acessos

  // Validação de dados: Status (col D)
  const regrasStatus = SpreadsheetApp.newDataValidation()
    .requireValueInList(['ATIVA', 'SUSPENSA', 'EXPIRADA', 'BLOQUEADA'], true)
    .setAllowInvalid(false)
    .build();
  abaLic.getRange(2, 4, 1000, 1).setDataValidation(regrasStatus);

  // Validação: Plano (col E)
  const regrasPlano = SpreadsheetApp.newDataValidation()
    .requireValueInList(['BASICO', 'PRO', 'ENTERPRISE'], true)
    .setAllowInvalid(false)
    .build();
  abaLic.getRange(2, 5, 1000, 1).setDataValidation(regrasPlano);

  // Formatação condicional: Status colorido
  const statusRange = abaLic.getRange('D2:D1000');

  const regrasFormatacao = [
    SpreadsheetApp.newConditionalFormatRule()
      .whenTextEqualTo('ATIVA').setBackground('#d4edda').setFontColor('#155724')
      .setRanges([statusRange]).build(),
    SpreadsheetApp.newConditionalFormatRule()
      .whenTextEqualTo('SUSPENSA').setBackground('#fff3cd').setFontColor('#856404')
      .setRanges([statusRange]).build(),
    SpreadsheetApp.newConditionalFormatRule()
      .whenTextEqualTo('EXPIRADA').setBackground('#f8d7da').setFontColor('#721c24')
      .setRanges([statusRange]).build(),
    SpreadsheetApp.newConditionalFormatRule()
      .whenTextEqualTo('BLOQUEADA').setBackground('#f5c6cb').setFontColor('#491217')
      .setRanges([statusRange]).build(),
  ];

  abaLic.setConditionalFormatRules(regrasFormatacao);

  // Linha de exemplo
  abaLic.getRange(2, 1, 1, 13).setValues([[
    'FISCAL-XXXX-YYYY-ZZZZ',
    'cliente@exemplo.com.br',
    'Empresa Exemplo LTDA',
    'ATIVA',
    'PRO',
    Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'dd/MM/yyyy'),
    '',
    0,
    '5.0',
    'Licença de demonstração',
    new Date(),
    '',
    0
  ]]);

  // ── Aba Log de Acessos ────────────────────────────────────
  let abaLog = ss.getSheetByName(CONFIG.ABA_LOG);
  if (!abaLog) {
    abaLog = ss.insertSheet(CONFIG.ABA_LOG);
  }

  const headerLog = ['Timestamp', 'Chave', 'Email', 'Versão', 'Resultado', 'Motivo', 'Usuário'];
  abaLog.getRange(1, 1, 1, headerLog.length).setValues([headerLog]);

  const headerRangeLog = abaLog.getRange(1, 1, 1, headerLog.length);
  headerRangeLog.setBackground('#2d3748');
  headerRangeLog.setFontColor('#ffffff');
  headerRangeLog.setFontWeight('bold');

  abaLog.setColumnWidth(1, 160);
  abaLog.setColumnWidth(2, 200);
  abaLog.setColumnWidth(3, 180);
  abaLog.setColumnWidth(4, 80);
  abaLog.setColumnWidth(5, 90);
  abaLog.setColumnWidth(6, 160);

  // Congela cabeçalhos
  abaLic.setFrozenRows(1);
  abaLog.setFrozenRows(1);

  SpreadsheetApp.getUi().alert(
    '✅ Planilha configurada com sucesso!\n\n' +
    'Próximos passos:\n' +
    '1. Vá em Extensões → Apps Script → Implantar → Nova implantação\n' +
    '2. Tipo: App da Web\n' +
    '3. Executar como: Eu mesmo\n' +
    '4. Quem tem acesso: Qualquer pessoa\n' +
    '5. Copie a URL gerada para o arquivo license.js da extensão'
  );
}

// ============================================================
// GERADOR DE CHAVE — use no Apps Script para gerar chaves
// ============================================================
function gerarChave(prefixo) {
  prefixo = prefixo || 'FISCAL';
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // sem 0/O, 1/I para evitar confusão
  function bloco(n) {
    let s = '';
    for (let i = 0; i < n; i++) s += chars[Math.floor(Math.random() * chars.length)];
    return s;
  }
  return `${prefixo}-${bloco(4)}-${bloco(4)}-${bloco(4)}`;
}

// Gera múltiplas chaves e impõe no Log para fácil cópia
function gerarLote(qtd, prefixo, plano, mesesValidade) {
  const ss  = SpreadsheetApp.getActiveSpreadsheet();
  const aba = ss.getSheetByName(CONFIG.ABA_LICENCAS);
  const hoje = new Date();

  let dataExpira = '';
  if (mesesValidade && mesesValidade > 0) {
    const expira = new Date(hoje);
    expira.setMonth(expira.getMonth() + mesesValidade);
    dataExpira = Utilities.formatDate(expira, Session.getScriptTimeZone(), 'dd/MM/yyyy');
  }

  const novas = [];
  for (let i = 0; i < (qtd || 1); i++) {
    const chave = gerarChave(prefixo || 'FISCAL');
    novas.push([
      chave,
      '',
      '',
      'ATIVA',
      plano || 'BASICO',
      Utilities.formatDate(hoje, Session.getScriptTimeZone(), 'dd/MM/yyyy'),
      dataExpira,
      0,
      '5.0',
      'Gerada em lote',
      hoje,
      '',
      0
    ]);
  }

  const lastRow = aba.getLastRow();
  aba.getRange(lastRow + 1, 1, novas.length, 13).setValues(novas);

  const ui = SpreadsheetApp.getUi();
  ui.alert(`✅ ${qtd} chave(s) gerada(s) com sucesso!\nVeja a aba "${CONFIG.ABA_LICENCAS}".`);
}

// Atalho: gere 10 chaves PRO com validade de 12 meses
function gerarLotePRO_12meses() {
  gerarLote(10, 'FISCAL', 'PRO', 12);
}
