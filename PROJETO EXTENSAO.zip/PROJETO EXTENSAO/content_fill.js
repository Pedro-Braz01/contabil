// content_fill.js — executa nas páginas de consulta fiscal
// Tenta preencher o campo CNPJ automaticamente; se não conseguir, mostra aviso

(async () => {

    const data = await chrome.storage.local.get(["cnpjParaConsulta", "cnpjTimestamp"]);
    const cnpj = data?.cnpjParaConsulta;
    const ts   = data?.cnpjTimestamp || 0;

    if (!cnpj || (Date.now() - ts) > 120_000) return;

    await chrome.storage.local.remove(["cnpjParaConsulta", "cnpjTimestamp"]);

    const cnpjFormatado = cnpj.replace(/^(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})$/, "$1.$2.$3/$4-$5");
    const host = location.hostname;

    // ── Função de cópia robusta ───────────────────────────────────────────────
    function copiarCnpj() {
        try {
            navigator.clipboard.writeText(cnpj).catch(() => {});
        } catch (_) {}
        try {
            const el = document.createElement("textarea");
            el.value = cnpj;
            el.style.cssText = `
                position: fixed;
                top: 50%;
                left: 50%;
                width: 1px;
                height: 1px;
                opacity: 0.01;
                z-index: 9999999;
                border: none;
                outline: none;
                padding: 0;
            `;
            document.body.appendChild(el);
            el.focus();
            el.select();
            el.setSelectionRange(0, el.value.length);
            document.execCommand("copy");
            document.body.removeChild(el);
        } catch (_) {}
    }

    // ── Setter nativo (dispara eventos React/Angular/etc.) ────────────────────
    function setValorNativo(campo, valor) {
        const nativeInput = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value");
        nativeInput.set.call(campo, valor);
        campo.dispatchEvent(new Event("input",  { bubbles: true }));
        campo.dispatchEvent(new Event("change", { bubbles: true }));
        campo.focus();
    }

    function setSelectNativo(sel, valor) {
        const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLSelectElement.prototype, "value");
        nativeSetter.set.call(sel, valor);
        sel.dispatchEvent(new Event("change", { bubbles: true }));
    }

    // ── Lógica específica por site ────────────────────────────────────────────

    // 1. CADESP — Secretaria da Fazenda SP (Consulta IE)
    //    Select id: ctl00_conteudoPaginaPlaceHolder_..._tipoFiltroDropDownList
    //    Opções: 0=IE, 1=CNPJ, 2=NIRE  → precisa setar value "1"
    //    Depois o PostBack do ASP.NET recarrega a página com o campo de texto correto.
    function tentarPreencherCadesp() {
        // Seletor direto pelo ID real do select
        const sel =
            document.getElementById("ctl00_conteudoPaginaPlaceHolder_filtroTabContainer_filtroEmitirCertidaoTabPanel_tipoFiltroDropDownList") ||
            // Fallback: qualquer select com as opções IE/CNPJ/NIRE
            Array.from(document.querySelectorAll("select")).find(s =>
                Array.from(s.options).some(o => o.value === "1" && o.text.trim() === "CNPJ")
            );

        if (!sel) return false;

        // Se já está em CNPJ (value "1"), só preenche o campo de texto
        if (sel.value === "1") {
            return preencherCampoCadesp();
        }

        // Muda para CNPJ e dispara o PostBack do ASP.NET
        setSelectNativo(sel, "1");

        // O site faz PostBack e recarrega — salva o CNPJ novamente no storage
        // para o content_fill rodar de novo na página recarregada.
        // Como já removemos do storage no topo, precisamos reinserir.
        chrome.storage.local.set({ cnpjParaConsulta: cnpj, cnpjTimestamp: Date.now() });

        // Dispara o onchange/PostBack do ASP.NET manualmente se necessário
        if (sel.onchange) sel.onchange();

        return false; // ainda não preencheu — vai preencher após o PostBack
    }

    function preencherCampoCadesp() {
        // Após o PostBack, o campo de texto para CNPJ aparece na página
        // Seletores prováveis para o input de identificação no CADESP
        const seletores = [
            'input[id*="filtroIdentificacaoTextBox" i]',
            'input[id*="identificacao" i]',
            'input[id*="Identificacao" i]',
            'input[name*="identificacao" i]',
        ];

        for (const s of seletores) {
            const campo = document.querySelector(s);
            if (!campo) continue;
            const style = window.getComputedStyle(campo);
            if (style.display === "none" || style.visibility === "hidden") continue;
            setValorNativo(campo, cnpjFormatado); // CADESP aceita formatado
            return true;
        }

        // Fallback: primeiro input de texto visível no formulário, excluindo captcha
        const inputs = document.querySelectorAll('input[type="text"]');
        for (const campo of inputs) {
            const style = window.getComputedStyle(campo);
            if (style.display === "none" || style.visibility === "hidden") continue;
            // Ignora campo de captcha (costuma ter maxlength pequeno <= 8)
            const maxlen = parseInt(campo.maxLength) || 999;
            if (maxlen > 0 && maxlen <= 8) continue;
            setValorNativo(campo, cnpjFormatado);
            return true;
        }
        return false;
    }

    // 2. Simples Nacional — campo exato: id="Cnpj" name="Cnpj" maxlength="14"
    function tentarPreencherSimples() {
        // Seletor direto pelo id/name reais do campo
        const campo =
            document.getElementById("Cnpj") ||
            document.querySelector('input[name="Cnpj"]') ||
            document.querySelector('input.numeric[maxlength="14"]');

        if (campo) {
            const style = window.getComputedStyle(campo);
            if (style.display !== "none" && style.visibility !== "hidden") {
                // maxlength=14 → só dígitos
                setValorNativo(campo, cnpj);
                return true;
            }
        }
        return false;
    }

    // 3. Ribeirão Preto IM — comportamento padrão
    function tentarPreencherGenerico() {
        const seletores = [
            'input[name*="cnpj" i]',
            'input[id*="cnpj" i]',
            'input[placeholder*="cnpj" i]',
            'input[placeholder*="CNPJ" i]',
            'input[type="text"]',
        ];
        for (const sel of seletores) {
            const campos = document.querySelectorAll(sel);
            for (const campo of campos) {
                const style = window.getComputedStyle(campo);
                if (style.display === "none" || style.visibility === "hidden") continue;
                const maxlen = parseInt(campo.maxLength) || 999;
                setValorNativo(campo, maxlen <= 14 ? cnpj : cnpjFormatado);
                return true;
            }
        }
        return false;
    }

    // ── Escolhe a função certa pelo host ──────────────────────────────────────
    const isCadesp  = host.includes("cadesp.fazenda.sp.gov.br");
    const isSimples = host.includes("receita.fazenda.gov.br") && location.href.includes("SimplesNacional");

    function tentarPreencher() {
        if (isCadesp)  return tentarPreencherCadesp();
        if (isSimples) return tentarPreencherSimples();
        return tentarPreencherGenerico();
    }

    // No CADESP, após o PostBack o select já vem em CNPJ (value "1").
    // As tentativas com delay pegam esse estado e chamam preencherCampoCadesp.
    function tentarPreencherComRetry() {
        if (isCadesp) {
            const sel =
                document.getElementById("ctl00_conteudoPaginaPlaceHolder_filtroTabContainer_filtroEmitirCertidaoTabPanel_tipoFiltroDropDownList") ||
                Array.from(document.querySelectorAll("select")).find(s =>
                    Array.from(s.options).some(o => o.value === "1" && o.text.trim() === "CNPJ")
                );
            // Se select já está em CNPJ (PostBack concluído), preenche o campo
            if (sel && sel.value === "1") return preencherCampoCadesp();
            return false;
        }
        return tentarPreencher();
    }

    // ── Tentativas com delay ──────────────────────────────────────────────────
    let preenchido = tentarPreencher();
    if (!preenchido) {
        await new Promise(r => setTimeout(r, 800));
        preenchido = tentarPreencherComRetry();
    }
    if (!preenchido) {
        await new Promise(r => setTimeout(r, 1500));
        preenchido = tentarPreencherComRetry();
    }

    // ── Monta o popup ─────────────────────────────────────────────────────────
    const overlay = document.createElement("div");
    overlay.id = "cfr-overlay";
    overlay.style.cssText = `
        position: fixed;
        top: 0; left: 0;
        width: 100%; height: 100%;
        background: rgba(0,0,0,0.45);
        z-index: 999998;
        display: flex;
        align-items: center;
        justify-content: center;
    `;

    const box = document.createElement("div");
    box.style.cssText = `
        background: #fff;
        border-radius: 12px;
        padding: 28px 32px;
        box-shadow: 0 8px 32px rgba(0,0,0,0.25);
        font-family: Arial, sans-serif;
        text-align: center;
        max-width: 360px;
        width: 90%;
        position: relative;
        z-index: 999999;
    `;

    if (preenchido) {
        box.innerHTML = `
            <div style="font-size:36px; margin-bottom:10px;">✅</div>
            <div style="font-size:17px; font-weight:bold; color:#15803d; margin-bottom:8px;">
                CNPJ preenchido!
            </div>
            <div style="font-size:14px; color:#555; margin-bottom:16px;">
                Campo preenchido automaticamente:
            </div>
            <div style="
                font-size:18px;
                font-weight:bold;
                color:#007bff;
                background:#f0f6ff;
                border-radius:8px;
                padding:10px 16px;
                margin-bottom:20px;
                letter-spacing:1px;
            ">${cnpjFormatado}</div>
            <button id="cfr-fechar" style="
                background:#15803d;
                color:#fff;
                border:none;
                border-radius:6px;
                padding:9px 28px;
                font-size:14px;
                font-weight:bold;
                cursor:pointer;
            ">OK</button>
        `;
    } else {
        box.innerHTML = `
            <div style="font-size:36px; margin-bottom:10px;">📋</div>
            <div style="font-size:17px; font-weight:bold; color:#333; margin-bottom:8px;">
                CNPJ copiado!
            </div>
            <div style="font-size:14px; color:#555; margin-bottom:16px;">
                CNPJ pronto para colar:
            </div>
            <div style="
                font-size:18px;
                font-weight:bold;
                color:#007bff;
                background:#f0f6ff;
                border-radius:8px;
                padding:10px 16px;
                margin-bottom:18px;
                letter-spacing:1px;
            ">${cnpjFormatado}</div>
            <div style="font-size:14px; color:#333; margin-bottom:6px;">
                Clique no campo CNPJ e pressione:
            </div>
            <div style="
                display:inline-block;
                background:#222;
                color:#fff;
                font-size:16px;
                font-weight:bold;
                border-radius:6px;
                padding:8px 20px;
                letter-spacing:2px;
                margin-bottom:20px;
            ">CTRL + V</div>
            <br>
            <button id="cfr-fechar" style="
                background:#007bff;
                color:#fff;
                border:none;
                border-radius:6px;
                padding:9px 28px;
                font-size:14px;
                font-weight:bold;
                cursor:pointer;
            ">Entendido</button>
        `;
    }

    overlay.appendChild(box);
    document.body.appendChild(overlay);

    copiarCnpj();
    setTimeout(() => copiarCnpj(), 300);

    document.getElementById("cfr-fechar").addEventListener("click", () => overlay.remove());
    overlay.addEventListener("click", (e) => { if (e.target === overlay) overlay.remove(); });

    setTimeout(() => overlay?.remove(), preenchido ? 2000 : 8000);

})();
