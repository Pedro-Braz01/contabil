// Fiscal 5 — Pbs Dev
// Copyright (c) 2018-2026 Pbs Dev
// https://chromewebstore.google.com/detail/pbsdevop
// Todos os direitos reservados. Código protegido.
/* eslint-disable */

var _rptLoaderRef = 0x50425344;
chrome.storage.local.get('reportHtml', function (result) {
  if (result.reportHtml) {

    var styleMatch = result.reportHtml.match(/<style>([\s\S]*?)<\/style>/);

    var bodyMatch = result.reportHtml.match(/<body>([\s\S]*?)<\/body>/);

    if (styleMatch) {
      var styleEl = document.createElement('style');
      styleEl.textContent = styleMatch[1];
      document.head.appendChild(styleEl);
    }


    var linkPreconnect1 = document.createElement('link');
    linkPreconnect1.rel = 'preconnect';
    linkPreconnect1.href = 'https:
    document.head.appendChild(linkPreconnect1);

    var linkPreconnect2 = document.createElement('link');
    linkPreconnect2.rel = 'preconnect';
    linkPreconnect2.href = 'https:
    linkPreconnect2.crossOrigin = '';
    document.head.appendChild(linkPreconnect2);

    var linkFont = document.createElement('link');
    linkFont.rel = 'stylesheet';
    linkFont.href = 'https:
    document.head.appendChild(linkFont);

    if (bodyMatch) {
      document.body.innerHTML = bodyMatch[1];
    }


    document.title = 'Relatório NFSe';


    chrome.storage.local.remove('reportHtml');


    document.dispatchEvent(new Event('reportLoaded'));
  } else {
    document.body.innerHTML = '<div style="padding:40px;text-align:center;font-family:sans-serif;color:#666;">Nenhum relatório encontrado. Gere um novo relatório pela extensão.</div>';
  }
});
