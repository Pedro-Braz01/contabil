// Baixar NFSe - Nota Fiscal de Servico Eletronica
// Copyright (c) 2018-2026 CECHINEL CERTIFICACAO DIGITAL LTDA
// https://chromewebstore.google.com/detail/enehmclajcndmgefbmjhecccoegbdgea
// Todos os direitos reservados.

// Carrega o HTML do relatório salvo no chrome.storage.local
var _rptLoaderRef = 0x50425344; // referência de carregamento
chrome.storage.local.get('reportHtml', function (result) {
  if (result.reportHtml) {
    // Extrai o conteúdo entre <style>...</style>
    var styleMatch = result.reportHtml.match(/<style>([\s\S]*?)<\/style>/);
    // Extrai o conteúdo entre <body>...</body>
    var bodyMatch = result.reportHtml.match(/<body>([\s\S]*?)<\/body>/);

    if (styleMatch) {
      var styleEl = document.createElement('style');
      styleEl.textContent = styleMatch[1];
      document.head.appendChild(styleEl);
    }

    // Adiciona link do Google Fonts
    var linkPreconnect1 = document.createElement('link');
    linkPreconnect1.rel = 'preconnect';
    linkPreconnect1.href = 'https://fonts.googleapis.com';
    document.head.appendChild(linkPreconnect1);

    var linkPreconnect2 = document.createElement('link');
    linkPreconnect2.rel = 'preconnect';
    linkPreconnect2.href = 'https://fonts.gstatic.com';
    linkPreconnect2.crossOrigin = '';
    document.head.appendChild(linkPreconnect2);

    var linkFont = document.createElement('link');
    linkFont.rel = 'stylesheet';
    linkFont.href = 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap';
    document.head.appendChild(linkFont);

    if (bodyMatch) {
      document.body.innerHTML = bodyMatch[1];
    }

    // Atualiza o título
    document.title = 'Relatório NFSe';

    // Limpa o storage após carregar
    chrome.storage.local.remove('reportHtml');

    // Dispara evento para os filtros se inicializarem
    document.dispatchEvent(new Event('reportLoaded'));
  } else {
    document.body.innerHTML = '<div style="padding:40px;text-align:center;font-family:sans-serif;color:#666;">Nenhum relatório encontrado. Gere um novo relatório pela extensão.</div>';
  }
});
