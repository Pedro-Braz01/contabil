// license-check-button.js - Botão de verificação de licença
document.addEventListener('DOMContentLoaded', function() {

    const btnVerifyLicense = document.getElementById('btnVerifyLicense');
    if (!btnVerifyLicense) return;

    function updateButtonState(text, color, disabled) {
        btnVerifyLicense.textContent = text;
        btnVerifyLicense.style.backgroundColor = color;
        btnVerifyLicense.disabled = !!disabled;
    }

    btnVerifyLicense.addEventListener('click', function () {
        updateButtonState('Verificando...', '#4d9fff', true);

        chrome.runtime.sendMessage({ action: 'renovarLicenca' }, function (result) {
            if (chrome.runtime.lastError) {
                updateButtonState('Erro de comunicação', '#dc2626', false);
                setTimeout(function () { updateButtonState('Verificar Licença', '#1a1f2e', false); }, 3000);
                return;
            }

            if (result && result.ok) {
                updateButtonState('Licença ATIVA ✅', '#15803d', false);
                var overlay = document.getElementById('licenseOverlay');
                if (overlay) overlay.classList.add('hidden');
            } else if (result && result.erro === 'OFFLINE') {
                updateButtonState('Offline 🛜', '#fde047', false);
            } else {
                updateButtonState('Licença INVÁLIDA ❌', '#dc2626', false);
                // Re-exibe o overlay de bloqueio
                var overlay = document.getElementById('licenseOverlay');
                if (overlay) {
                    overlay.classList.remove('hidden');
                    var ovStatus = document.getElementById('ovStatus');
                    var ovForm   = document.getElementById('ovForm');
                    if (ovStatus) {
                        ovStatus.className = 'ov-status erro';
                        ovStatus.textContent = (result && result.msg) ? result.msg : 'Licença inválida.';
                    }
                    if (ovForm) ovForm.style.display = 'block';
                }
            }

            setTimeout(function () {
                updateButtonState('Verificar Licença', '#1a1f2e', false);
            }, 3000);
        });
    });
});
