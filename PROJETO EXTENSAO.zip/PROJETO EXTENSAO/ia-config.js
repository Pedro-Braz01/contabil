// Fiscal 5 — Pbs Dev
// Copyright (c) 2018-2026 Pbs Dev
// Todos os direitos reservados. Código protegido.
/* eslint-disable */

// A chave da API Gemini é lida do chrome.storage em runtime — nunca fica hardcoded no código.
// Para configurar: salve a chave via chrome.storage.local.set({ _ia_k: 'SUA_CHAVE_AQUI' })
const IA_CONFIG = (function() {
  var _m = (function(){var _k=42,_a=[106,111,64,95,90,91,88,77,74,72,68,21,83,79,87,72];return _a.map(function(c,i){return String.fromCharCode(c^(_k+i%7))}).join('')})();
  return {
    get MODEL() { return _m; },
    get API_KEY() {
      // Lida de storage em runtime — nunca exposta no código
      return typeof _ia_runtime_key !== 'undefined' ? _ia_runtime_key : '';
    },
    get API_URL() {
      return 'https://generativelanguage.googleapis.com/v1beta/models/' + this.MODEL + ':generateContent?key=' + this.API_KEY;
    }
  };
})();

// Carrega a chave em runtime (injeta na variável global do contexto correto)
if (typeof chrome !== 'undefined' && chrome.storage) {
  chrome.storage.local.get('_ia_k', function(r) {
    if (r && r._ia_k) { try { window._ia_runtime_key = r._ia_k; } catch(e) {} }
  });
}
