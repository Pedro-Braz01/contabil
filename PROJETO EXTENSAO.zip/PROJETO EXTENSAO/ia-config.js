// ============================================================
// CONFIGURAÇÃO DA IA — Troque aqui quando mudar de chave/modelo
// ============================================================

const IA_CONFIG = {

  // Chave API atual
  API_KEY: '',

  // Modelo atual (Gemini)
  // Outros modelos disponíveis no Google AI Studio:
  //   gemini-2.0-flash         ← atual (rápido e gratuito)
  //   gemini-2.0-pro
  //   gemini-1.5-flash
  //   gemini-1.5-pro
  MODEL: 'gemini-2.0-flash',

  // URL base da API — não altere, muda automaticamente com MODEL e API_KEY
  get API_URL() {
    return `https://generativelanguage.googleapis.com/v1beta/models/${this.MODEL}:generateContent?key=${this.API_KEY}`;
  }

};
