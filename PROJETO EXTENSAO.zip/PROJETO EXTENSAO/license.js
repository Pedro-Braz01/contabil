// ============================================================
// license.js — Módulo de Controle de Licença
// Fiscal 5 — CECHINEL CERTIFICACAO DIGITAL LTDA
// Inclua este arquivo no manifest.json e chame initLicenca()
// ============================================================

const LICENSE = (() => {

  // ── CONFIGURE AQUI ─────────────────────────────────────────
  // Cole a URL gerada no deploy do Google Apps Script
  const APPS_SCRIPT_URL = 'https://script.google.com/macros/s/AKfycbzUphOBT-ZBUF0BN0V29rWudjJfNg7yEA1AFotUx0KNJ9NwCew09QyLLJwdpZn4spgM/exec';

  // Chave secreta (MESMA do Apps Script — CONFIG.CHAVE_SECRETA)
  const CHAVE_SECRETA = 'FISCAL_PBS_2026_SECURE';

  // Versão atual da extensão (deve bater com manifest.json)
  const VERSAO = '5.0';

  // Tempo de cache local da licença válida (ms)
  const CACHE_VALIDADE_MS = 4 * 60 * 60 * 1000; // 4 horas

  // Tempo máximo de cache offline (ms) — usa licença em cache se API cair
  const CACHE_OFFLINE_MS = 7 * 24 * 60 * 60 * 1000; // 7 dias

  // ── STORAGE KEYS ───────────────────────────────────────────
  const KEY_CHAVE    = 'license_chave';
  const KEY_EMAIL    = 'license_email';
  const KEY_CACHE    = 'license_cache';
  const KEY_BLOQUEIO = 'license_bloqueio';

  // ── GERA TOKEN para autenticar a requisição ─────────────────
  // Usa SubtleCrypto (disponível em service workers / extensões MV3)
  async function gerarToken(chave) {
    const dados  = String(chave).trim().toUpperCase() + CHAVE_SECRETA;
    const encoder = new TextEncoder();
    const buffer  = await crypto.subtle.digest('SHA-256', encoder.encode(dados));
    const hashArray = Array.from(new Uint8Array(buffer));
    const hex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
    return hex.substring(0, 32);
  }

  // ── SALVA CREDENCIAIS ───────────────────────────────────────
  async function salvarCredenciais(chave, email) {
    await chrome.storage.local.set({
      [KEY_CHAVE]: chave,
      [KEY_EMAIL]: email || '',
    });
  }

  // ── CARREGA CREDENCIAIS ─────────────────────────────────────
  async function carregarCredenciais() {
    const data = await chrome.storage.local.get([KEY_CHAVE, KEY_EMAIL]);
    return {
      chave: data[KEY_CHAVE] || '',
      email: data[KEY_EMAIL] || '',
    };
  }

  // ── LIMPA CREDENCIAIS (logout/desativar) ────────────────────
  async function limparCredenciais() {
    await chrome.storage.local.remove([KEY_CHAVE, KEY_EMAIL, KEY_CACHE, KEY_BLOQUEIO]);
  }

  // ── LÊ CACHE LOCAL ──────────────────────────────────────────
  async function lerCache() {
    const data = await chrome.storage.local.get(KEY_CACHE);
    return data[KEY_CACHE] || null;
  }

  // ── SALVA CACHE LOCAL ───────────────────────────────────────
  async function salvarCache(resultado) {
    await chrome.storage.local.set({
      [KEY_CACHE]: {
        ...resultado,
        _cachedAt: Date.now(),
      }
    });
  }

  // ── CACHE AINDA VÁLIDO? ─────────────────────────────────────
  function cacheValido(cache) {
    if (!cache || !cache._cachedAt) return false;
    return (Date.now() - cache._cachedAt) < CACHE_VALIDADE_MS;
  }

  // ── CACHE AINDA USÁVEL OFFLINE? ────────────────────────────
  function cacheOfflineValido(cache) {
    if (!cache || !cache._cachedAt) return false;
    return (Date.now() - cache._cachedAt) < CACHE_OFFLINE_MS;
  }

  // ── VERIFICAR LICENÇA ONLINE ────────────────────────────────
  async function verificarOnline(chave, email) {
    const token = await gerarToken(chave);

    const body = JSON.stringify({
      action:  'verificar',
      chave:   chave.trim().toUpperCase(),
      email:   (email || '').trim().toLowerCase(),
      versao:  VERSAO,
      token:   token,
    });

    const resp = await fetch(APPS_SCRIPT_URL, {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    body,
    });

    if (!resp.ok) {
      throw new Error(`HTTP ${resp.status}`);
    }

    const data = await resp.json();
    return data;
  }

  // ── VERIFICAR LICENÇA (com cache) ───────────────────────────
  async function verificar(forcarOnline = false) {
    const creds = await carregarCredenciais();

    if (!creds.chave) {
      return { ok: false, erro: 'SEM_CHAVE', msg: 'Nenhuma licença ativada.' };
    }

    // 1. Cache válido e não forçando online
    if (!forcarOnline) {
      const cache = await lerCache();
      if (cacheValido(cache) && cache.ok) {
        return { ...cache, _fonte: 'cache' };
      }
    }

    // 2. Tenta verificar online
    try {
      const resultado = await verificarOnline(creds.chave, creds.email);

      // Salva cache apenas se OK
      if (resultado.ok) {
        await salvarCache(resultado);
        await chrome.storage.local.remove(KEY_BLOQUEIO);
      } else {
        // Licença bloqueada/inválida — salva o bloqueio
        await chrome.storage.local.set({ [KEY_BLOQUEIO]: resultado });
        await salvarCache({ ok: false, _cachedAt: Date.now(), ...resultado });
      }

      return resultado;

    } catch (err) {
      // 3. Offline ou API fora: usa cache antigo se ainda válido
      const cache = await lerCache();
      if (cache && cache.ok && cacheOfflineValido(cache)) {
        console.warn('[License] API offline, usando cache local:', err.message);
        return { ...cache, _fonte: 'cache_offline', _aviso: 'Verificação offline — conecte-se para renovar.' };
      }

      // 4. Sem cache válido e sem conexão
      return {
        ok: false,
        erro: 'OFFLINE',
        msg: 'Não foi possível verificar a licença. Verifique sua conexão.',
      };
    }
  }

  // ── ATIVAR LICENÇA ──────────────────────────────────────────
  async function ativar(chave, email) {
    chave = String(chave || '').trim().toUpperCase();
    email = String(email || '').trim().toLowerCase();

    if (!chave) return { ok: false, msg: 'Informe a chave de licença.' };
    if (!email) return { ok: false, msg: 'Informe o e-mail.' };
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return { ok: false, msg: 'E-mail inválido.' };
    }

    const token = await gerarToken(chave);

    try {
      const resp = await fetch(APPS_SCRIPT_URL, {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'ativar',
          chave, email, versao: VERSAO, token,
        }),
      });

      const data = await resp.json();

      if (data.ok) {
        await salvarCredenciais(chave, email);
        await chrome.storage.local.remove([KEY_CACHE, KEY_BLOQUEIO]);
      }

      return data;

    } catch (err) {
      return { ok: false, erro: 'OFFLINE', msg: 'Sem conexão com o servidor de licenças.' };
    }
  }

  // ── CHAVE ATUAL ─────────────────────────────────────────────
  async function getChave() {
    const data = await chrome.storage.local.get(KEY_CHAVE);
    return data[KEY_CHAVE] || '';
  }

  // ── INICIALIZAÇÃO (chame no início do background.js) ────────
  // Retorna { ok, erro, msg, plano, diasRestantes, ... }
  async function init() {
    const result = await verificar();

    if (!result.ok) {
      console.warn('[License] Acesso negado:', result.erro, result.msg);
    } else {
      console.log('[License] OK — Plano:', result.plano,
        result.diasRestantes != null ? `| Expira em ${result.diasRestantes} dias` : '| Sem expiração');
    }

    return result;
  }

  // API pública
  return { init, verificar, ativar, limparCredenciais, getChave, carregarCredenciais };

})();
