// Fiscal 5 — Pbs Dev
// Copyright (c) 2018-2026 Pbs Dev
// https://chromewebstore.google.com/detail/pbsdevop
// Todos os direitos reservados. Código protegido.
/* eslint-disable */


const LICENSE = (() => {

  
  
  const APPS_SCRIPT_URL = 'https:

  
  const CHAVE_SECRETA = (function(){var _k=42,_a=[108,98,127,110,111,99,111,122,105,127,114,28,31,2,28,116,127,104,109,122,98,111];return _a.map(function(c,i){return String.fromCharCode(c^(_k+i%7))}).join('')})();

  
  const VERSAO = '5.0';

  
  const CACHE_VALIDADE_MS = 4 * 60 * 60 * 1000; 

  
  const CACHE_OFFLINE_MS = 7 * 24 * 60 * 60 * 1000; 

  
  const KEY_CHAVE    = 'license_chave';
  const KEY_EMAIL    = 'license_email';
  const KEY_CACHE    = 'license_cache';
  const KEY_BLOQUEIO = 'license_bloqueio';

  
  
  async function gerarToken(chave) {
    const dados  = String(chave).trim().toUpperCase() + CHAVE_SECRETA;
    const encoder = new TextEncoder();
    const buffer  = await crypto.subtle.digest('SHA-256', encoder.encode(dados));
    const hashArray = Array.from(new Uint8Array(buffer));
    const hex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
    return hex.substring(0, 32);
  }

  
  async function salvarCredenciais(chave, email) {
    await chrome.storage.local.set({
      [KEY_CHAVE]: chave,
      [KEY_EMAIL]: email || '',
    });
  }

  
  async function carregarCredenciais() {
    const data = await chrome.storage.local.get([KEY_CHAVE, KEY_EMAIL]);
    return {
      chave: data[KEY_CHAVE] || '',
      email: data[KEY_EMAIL] || '',
    };
  }

  
  async function limparCredenciais() {
    await chrome.storage.local.remove([KEY_CHAVE, KEY_EMAIL, KEY_CACHE, KEY_BLOQUEIO]);
  }

  
  async function lerCache() {
    const data = await chrome.storage.local.get(KEY_CACHE);
    return data[KEY_CACHE] || null;
  }

  
  async function salvarCache(resultado) {
    await chrome.storage.local.set({
      [KEY_CACHE]: {
        ...resultado,
        _cachedAt: Date.now(),
      }
    });
  }

  
  function cacheValido(cache) {
    if (!cache || !cache._cachedAt) return false;
    return (Date.now() - cache._cachedAt) < CACHE_VALIDADE_MS;
  }

  
  function cacheOfflineValido(cache) {
    if (!cache || !cache._cachedAt) return false;
    return (Date.now() - cache._cachedAt) < CACHE_OFFLINE_MS;
  }

  
  async function verificarOnline(chave, email) {
    const token = await gerarToken(chave);

    const body = JSON.stringify({
      action:  'verificar',
      chave:   chave.trim().toUpperCase(),
      email:   (email || '').trim().toLowerCase(),
      versao:  VERSAO,
      token:   token,
    });

    const resp = await fetch(APPS_SCRIPT_URL, {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    body,
    });

    if (!resp.ok) {
      throw new Error(`HTTP ${resp.status}`);
    }

    const data = await resp.json();
    return data;
  }

  
  async function verificar(forcarOnline = false) {
    const creds = await carregarCredenciais();

    if (!creds.chave) {
      return { ok: false, erro: 'SEM_CHAVE', msg: 'Nenhuma licença ativada.' };
    }

    
    if (!forcarOnline) {
      const cache = await lerCache();
      if (cacheValido(cache) && cache.ok) {
        return { ...cache, _fonte: 'cache' };
      }
    }

    
    try {
      const resultado = await verificarOnline(creds.chave, creds.email);

      
      if (resultado.ok) {
        await salvarCache(resultado);
        await chrome.storage.local.remove(KEY_BLOQUEIO);
      } else {
        
        await chrome.storage.local.set({ [KEY_BLOQUEIO]: resultado });
        await salvarCache({ ok: false, _cachedAt: Date.now(), ...resultado });
      }

      return resultado;

    } catch (err) {
      
      const cache = await lerCache();
      if (cache && cache.ok && cacheOfflineValido(cache)) {
        console.warn('[License] API offline, usando cache local:', err.message);
        return { ...cache, _fonte: 'cache_offline', _aviso: 'Verificação offline — conecte-se para renovar.' };
      }

      
      return {
        ok: false,
        erro: 'OFFLINE',
        msg: 'Não foi possível verificar a licença. Verifique sua conexão.',
      };
    }
  }

  
  async function ativar(chave, email) {
    chave = String(chave || '').trim().toUpperCase();
    email = String(email || '').trim().toLowerCase();

    if (!chave) return { ok: false, msg: 'Informe a chave de licença.' };
    if (!email) return { ok: false, msg: 'Informe o e-mail.' };
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return { ok: false, msg: 'E-mail inválido.' };
    }

    const token = await gerarToken(chave);

    try {
      const resp = await fetch(APPS_SCRIPT_URL, {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'ativar',
          chave, email, versao: VERSAO, token,
        }),
      });

      const data = await resp.json();

      if (data.ok) {
        await salvarCredenciais(chave, email);
        await chrome.storage.local.remove([KEY_CACHE, KEY_BLOQUEIO]);
      }

      return data;

    } catch (err) {
      return { ok: false, erro: 'OFFLINE', msg: 'Sem conexão com o servidor de licenças.' };
    }
  }

  
  async function getChave() {
    const data = await chrome.storage.local.get(KEY_CHAVE);
    return data[KEY_CHAVE] || '';
  }

  
  
  async function init() {
    const result = await verificar();

    if (!result.ok) {
      console.warn('[License] Acesso negado:', result.erro, result.msg);
    } else {
      console.log('[License] OK — Plano:', result.plano,
        result.diasRestantes != null ? `| Expira em ${result.diasRestantes} dias` : '| Sem expiração');
    }

    return result;
  }

  
  return { init, verificar, ativar, limparCredenciais, getChave, carregarCredenciais };

})();
