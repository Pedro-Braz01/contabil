# 🔐 Sistema de Licenças — Fiscal 5
## Guia Completo: Instalação + Análise de Segurança

---

## 📦 ARQUIVOS GERADOS

| Arquivo | Onde vai | Descrição |
|---|---|---|
| `Codigo.gs` | Google Apps Script | Backend do servidor de licenças |
| `license.js` | Raiz da extensão | Módulo cliente de verificação |
| `license-screen.html` | Raiz da extensão | Tela de ativação |

---

## 🚀 PASSO A PASSO DE INSTALAÇÃO

### 1. Configurar o Google Sheets + Apps Script

1. Crie uma nova Planilha Google (ou abra uma existente)
2. Acesse **Extensões → Apps Script**
3. Delete o código padrão e cole todo o conteúdo de `Codigo.gs`
4. Clique em **Salvar**
5. No menu, execute a função **`setupPlanilha`** — ela cria automaticamente as abas, formatações e validações
6. Acesse **Implantar → Nova implantação**:
   - Tipo: **App da Web**
   - Executar como: **Eu mesmo**
   - Quem tem acesso: **Qualquer pessoa**
7. Clique em **Implantar** e copie a URL gerada

### 2. Configurar a extensão

**Em `license.js`**, substitua:
```js
const APPS_SCRIPT_URL = 'https://script.google.com/macros/s/SEU_DEPLOYMENT_ID/exec';
const CHAVE_SECRETA   = 'FISCAL_PBS_2026_@#$';  // igual ao Apps Script
```

**Em `manifest.json`**, adicione:
```json
{
  "host_permissions": [
    "https://script.google.com/*"
  ],
  "web_accessible_resources": [
    {
      "resources": ["license.js", "license-screen.html"],
      "matches": ["<all_urls>"]
    }
  ]
}
```

### 3. Integrar no background.js

No **início** do `background.js`, adicione:

```js
// ── CONTROLE DE LICENÇA ───────────────────────────────────
importScripts('license.js');  // se usar module worker

// OU inclua no manifest como script adicional do service_worker:
// "background": { "service_worker": "background.js", "scripts": ["license.js"] }

// Verificação na inicialização
let _licencaOk = false;

async function verificarLicencaInicial() {
  const result = await LICENSE.verificar();
  _licencaOk = result.ok;

  if (!result.ok) {
    // Abre tela de ativação no sidepanel
    chrome.sidePanel.setOptions({ path: 'license-screen.html', enabled: true });
    console.warn('[License] Bloqueado:', result.msg);
  }
  return result;
}

verificarLicencaInicial();

// Protege funções sensíveis — exemplo no listener de mensagens:
// if (!_licencaOk) { sendResponse({ error: 'LICENSE_REQUIRED' }); return; }
```

### 4. Bloquear uso sem licença no sidepanel.js

No início do `sidepanel.js`, adicione:
```js
// Verifica licença ao abrir o painel
chrome.runtime.sendMessage({ action: 'checkLicense' }, (result) => {
  if (!result || !result.ok) {
    window.location.href = chrome.runtime.getURL('license-screen.html');
  }
});
```

No `background.js`, no listener de mensagens:
```js
if (message.action === 'checkLicense') {
  LICENSE.verificar().then(r => sendResponse(r));
  return true;
}
```

---

## 🗂️ ESTRUTURA DA PLANILHA

### Aba "Licenças"

| Col | Campo | Exemplo | Notas |
|---|---|---|---|
| A | **Chave** | `FISCAL-AB3K-CD7M-EF9P` | Gerada pelo `gerarLote()` |
| B | **Email** | `cliente@empresa.com` | Preenchido na 1ª ativação |
| C | **Nome/Empresa** | `Contabilidade ABC` | Opcional |
| D | **Status** | `ATIVA` | ATIVA / SUSPENSA / EXPIRADA / BLOQUEADA |
| E | **Plano** | `PRO` | BASICO / PRO / ENTERPRISE |
| F | **Data Início** | `01/01/2026` | dd/MM/yyyy |
| G | **Data Expira** | `31/12/2026` | Vazio = sem expiração |
| H | **Dispositivos** | `0` | 0 = ilimitado |
| I | **Versão Min** | `5.0` | Versão mínima aceita |
| J | **Observações** | `Cliente VIP` | Livre |
| K | **Criado em** | (auto) | Timestamp |
| L | **Último Acesso** | (auto) | Atualizado a cada check |
| M | **Total Acessos** | (auto) | Contador cumulativo |

### Gerar chaves em lote

No Apps Script, execute `gerarLote(qtd, prefixo, plano, mesesValidade)`:
```js
gerarLote(50, 'FISCAL', 'PRO', 12)   // 50 chaves PRO com validade 12 meses
gerarLote(10, 'FISCAL', 'BASICO', 0) // 10 chaves sem expiração
```

---

## 🔒 ANÁLISE DE SEGURANÇA DO PROJETO

### ⚠️ VULNERABILIDADES CRÍTICAS ENCONTRADAS

#### 1. 🔴 API KEY do Gemini exposta no código (`ia-config.js`)
```js
// ARQUIVO: ia-config.js — LINHA 4
API_KEY: 'AIzaSyCg61vfhE8NRH2ShrzlL7ain-1HDRR3xFk',
```
**Risco:** A chave está em texto plano no código da extensão. Qualquer pessoa que instale a extensão pode extraí-la e usar sua cota gratuitamente ou gerar custos.

**Correção:**
- Remova a chave do código cliente
- Use um proxy: extensão → seu backend → Gemini API
- Se não puder criar um backend, use a chave com restrições de domínio/referrer no Google Cloud Console
- Mude a chave imediatamente se ela já foi exposta em algum repositório

---

#### 2. 🟡 Permissão `<all_urls>` muito ampla (`manifest.json`)
```json
"host_permissions": ["<all_urls>"]
```
**Risco:** A extensão pode fazer fetch em qualquer domínio, o que aumenta a superfície de ataque e pode causar rejeição na revisão da Chrome Web Store.

**Correção:** Limite apenas ao necessário:
```json
"host_permissions": [
  "https://www.nfse.gov.br/*",
  "https://www8.receita.fazenda.gov.br/*",
  "https://solucoes.receita.fazenda.gov.br/*",
  "https://www.cadesp.fazenda.sp.gov.br/*",
  "https://www.ribeiraopreto.sp.gov.br/*",
  "https://generativelanguage.googleapis.com/*",
  "https://notarp.com.br/*",
  "https://issnetonline.com.br/*"
]
```

---

#### 3. 🟡 `report-loader.js` injeta HTML bruto do storage (`innerHTML`)
```js
// ARQUIVO: report-loader.js — linha 25
document.body.innerHTML = bodyMatch[1];
```
**Risco:** Se um atacante conseguir escrever em `chrome.storage.local` (ex.: via extensão maliciosa ou XSS em outra parte), pode executar scripts na página do relatório.

**Correção:** Use `DOMParser` + `sanitize` ou valide o HTML antes de injetar.

---

#### 4. 🟡 `content_fill.js` insere overlay em qualquer página
O content script injeta DOM em sites de terceiros com z-index altíssimo. Embora seguro no design atual, é um vetor de clickjacking em versões futuras.

**Recomendação:** Adicione verificação de domínio antes de injetar o overlay.

---

#### 5. 🟢 `incognito: "spanning"` no manifest
Permite que a extensão rode em janelas anônimas. Isso é necessário para o funcionamento mas vale **documentar** para os usuários que dados da sessão normal podem cruzar com a anônima.

---

### ✅ BOAS PRÁTICAS JÁ PRESENTES

- Uso de MV3 (Manifest V3) — mais seguro e moderno
- `offscreen.html` para parsing DOM isolado do service worker
- Timeout em todas as requisições de rede
- Retry automático com limite de tentativas
- Sessão expirada detectada e comunicada ao usuário
- Content scripts restritos a URLs específicas (não são `<all_urls>`)
- `chrome.storage.local` para dados sensíveis (não `localStorage`)
- Sanitização de nomes de arquivo antes de salvar

---

## 🔑 FLUXO DE VERIFICAÇÃO DE LICENÇA

```
Extensão abre
     ↓
LICENSE.verificar()
     ↓
Cache local válido? ──YES──→ Libera (sem chamada de rede)
     ↓ NO
Chama Apps Script via POST
     ↓
Apps Script verifica planilha
     ↓
OK? ──YES──→ Salva cache 4h → Libera extensão
     ↓ NO
Erro de rede? ──YES──→ Usa cache offline (até 7 dias)
     ↓ NO
Bloqueia + redireciona para license-screen.html
```

---

## 📋 CHECKLIST DE DEPLOY

- [ ] Trocar `APPS_SCRIPT_URL` pelo ID real do deploy
- [ ] Trocar `CHAVE_SECRETA` por um valor forte e secreto
- [ ] Trocar/revogar a chave Gemini exposta em `ia-config.js`
- [ ] Executar `setupPlanilha()` no Apps Script
- [ ] Adicionar `license.js` ao `manifest.json`
- [ ] Adicionar `https://script.google.com/*` ao `host_permissions`
- [ ] Testar fluxo: sem chave → com chave válida → chave expirada
- [ ] Gerar primeiro lote de chaves com `gerarLote()`
