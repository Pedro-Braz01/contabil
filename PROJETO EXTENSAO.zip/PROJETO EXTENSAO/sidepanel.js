// ── VERIFICAÇÃO DE LICENÇA COM BLOQUEIO ──────────────────────────────────────
// O overlay #licenseOverlay bloqueia toda a interface até a licença ser validada
(function verificarLicencaSidepanel() {
  const overlay  = document.getElementById('licenseOverlay');
  const ovStatus = document.getElementById('ovStatus');
  const ovForm   = document.getElementById('ovForm');

  chrome.runtime.sendMessage({ action: 'checkLicense' }, function (result) {
    if (chrome.runtime.lastError) {
      // Service worker ainda iniciando — tenta novamente em 1s
      setTimeout(verificarLicencaSidepanel, 1000);
      return;
    }
    if (result && result.ok) {
      // Licença válida — libera a interface
      overlay.classList.add('hidden');
    } else {
      // Licença inválida — mostra formulário de ativação
      ovStatus.className = 'ov-status erro';
      ovStatus.textContent = result?.msg || 'Licença inválida ou não encontrada.';
      ovForm.style.display = 'block';

      // Preenche campos se já houver credenciais salvas
      chrome.runtime.sendMessage({ action: 'getLicenseInfo' }, function (info) {
        if (info && info.chave) document.getElementById('ovChave').value = info.chave;
        if (info && info.email) document.getElementById('ovEmail').value = info.email;
      });
    }
  });
})();

// ── Formatar chave no overlay enquanto digita ────────────────────────────────
const ovChaveInput = document.getElementById('ovChave');
if (ovChaveInput) {
  ovChaveInput.addEventListener('input', function () {
    let v = this.value.toUpperCase().replace(/[^A-Z0-9]/g, '');
    if (v.startsWith('FISCAL')) {
      const prefixo = v.substring(0, 6);
      const resto = v.substring(6).replace(/(.{4})/g, '$1-').replace(/-$/, '');
      this.value = resto ? prefixo + '-' + resto : prefixo;
    }
  });
}

// ── Botão Ativar no overlay ──────────────────────────────────────────────────
document.getElementById('ovBtnAtivar').addEventListener('click', function () {
  const overlay  = document.getElementById('licenseOverlay');
  const ovStatus = document.getElementById('ovStatus');
  const btn      = this;
  const chave    = document.getElementById('ovChave').value.trim();
  const email    = document.getElementById('ovEmail').value.trim();

  if (!chave || !email) {
    ovStatus.className = 'ov-status erro';
    ovStatus.textContent = 'Preencha a chave e o e-mail.';
    return;
  }

  btn.disabled = true;
  btn.textContent = 'Verificando...';
  ovStatus.className = 'ov-status loading';
  ovStatus.textContent = 'Ativando licença...';

  chrome.runtime.sendMessage({ action: 'salvarLicenca', chave, email }, function (result) {
    btn.disabled = false;
    btn.textContent = 'Ativar Licença';

    if (result && result.ok) {
      ovStatus.className = 'ov-status ok';
      ovStatus.textContent = '✅ Licença ativada com sucesso!';
      // Libera a interface após 1s
      setTimeout(() => overlay.classList.add('hidden'), 1000);
    } else {
      ovStatus.className = 'ov-status erro';
      ovStatus.textContent = '❌ ' + (result?.msg || 'Erro ao ativar licença.');
    }
  });
});
// ─────────────────────────────────────────────────────────────────────────────

const DEFAULTS = { pis: 0.65, cofins: 3.00, irrf: 1.50, csll: 1.00 };

function formatarMoeda(v) {
    return v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}
function formatarNumero(v) {
    return v.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}
function formatarCnpj(s) {
    return s.replace(/^(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})$/, "$1.$2.$3/$4-$5");
}
function delay(ms) { return new Promise(r => setTimeout(r, ms)); }

async function carregarAliquotas() {
    const data = await chrome.storage.local.get("aliquotas");
    return Object.assign({}, DEFAULTS, data.aliquotas || {});
}

// ── Tabs ──────────────────────────────────────────────────────────────────────
document.querySelectorAll(".tab-btn").forEach(btn => {
    btn.addEventListener("click", () => {
        document.querySelectorAll(".tab-btn").forEach(b => b.classList.remove("active"));
        document.querySelectorAll(".page").forEach(p => p.classList.remove("active"));
        btn.classList.add("active");
        document.getElementById("tab-" + btn.dataset.tab).classList.add("active");
        if (btn.dataset.tab === "config") inicializarConfig();
    });
});

// ── Máscara de valor ──────────────────────────────────────────────────────────
document.getElementById("valor").addEventListener("input", function (e) {
    let v = e.target.value.replace(/\D/g, "");
    v = (v / 100).toFixed(2) + "";
    v = v.replace(".", ",").replace(/\B(?=(\d{3})+(?!\d))/g, ".");
    e.target.value = "R$ " + v;
});

// ── Copiar valor ──────────────────────────────────────────────────────────────
async function copiarValor(valorNumerico, linha) {
    try { await navigator.clipboard.writeText(formatarNumero(valorNumerico)); } catch (_) {}
    linha.classList.add("copied-flash");
    const nomeEl = linha.querySelector(".imposto-nome");
    if (nomeEl) {
        const bkp = nomeEl.textContent;
        nomeEl.textContent = "✔ Copiado!";
        setTimeout(() => { linha.classList.remove("copied-flash"); nomeEl.textContent = bkp; }, 800);
    }
}

// ── Buscar CNPJ na aba ────────────────────────────────────────────────────────
async function buscarCnpjNaAba() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    try {
        const results = await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            func: () => {
                const regex = /\b\d{2}\.?\d{3}\.?\d{3}[\/]?\d{4}[-]?\d{2}\b/g;
                const matches = (document.body.innerText || "").match(regex);
                if (!matches) return null;
                const validos = matches.filter(m => m.replace(/\D/g, "").length === 14);
                return validos.length > 0 ? validos[0] : null;
            }
        });
        if (results?.[0]?.result) return results[0].result.replace(/\D/g, "");
    } catch (err) { console.warn("Não foi possível ler a aba:", err.message); }
    return null;
}

// ── Consultar Regime ──────────────────────────────────────────────────────────
document.getElementById("abrirSite").addEventListener("click", async () => {
    const btn = document.getElementById("abrirSite");
    const status = document.getElementById("statusCnpj");
    btn.disabled = true;
    status.className = "status";
    status.textContent = "Buscando CNPJ na página...";
    const cnpj = await buscarCnpjNaAba();
    if (cnpj) {
        try { await navigator.clipboard.writeText(cnpj); } catch (_) {}
        await chrome.storage.local.set({ cnpjParaConsulta: cnpj, cnpjTimestamp: Date.now() });
        status.className = "status ok";
        status.textContent = `✔ CNPJ: ${formatarCnpj(cnpj)}`;
        await delay(2000);
        chrome.tabs.create({ url: "https://www8.receita.fazenda.gov.br/SimplesNacional/aplicacoes.aspx?id=21" });
    } else {
        await chrome.storage.local.remove("cnpjParaConsulta");
        status.className = "status erro";
        status.textContent = "Nenhum CNPJ encontrado. Abrindo em 3s...";
        await delay(3000);
        chrome.tabs.create({ url: "https://www8.receita.fazenda.gov.br/SimplesNacional/aplicacoes.aspx?id=21" });
    }
    btn.disabled = false;
});

// ── Consultar CNPJ ────────────────────────────────────────────────────────────
document.getElementById("consultarCnpj").addEventListener("click", async () => {
    const btn = document.getElementById("consultarCnpj");
    const status = document.getElementById("statusCnpj");
    btn.disabled = true;
    status.className = "status";
    status.textContent = "Buscando CNPJ na página...";
    const cnpj = await buscarCnpjNaAba();
    if (cnpj) {
        try { await navigator.clipboard.writeText(cnpj); } catch (_) {}
        status.className = "status ok";
        status.textContent = `✔ CNPJ: ${formatarCnpj(cnpj)}`;
    } else {
        status.className = "status erro";
        status.textContent = "Nenhum CNPJ encontrado. Abrindo em 3s...";
    }
    await delay(3000);
    chrome.tabs.create({ url: `https://solucoes.receita.fazenda.gov.br/servicos/cnpjreva/Cnpjreva_Solicitacao.asp?cnpj=${cnpj || ""}` });
    btn.disabled = false;
});

// ── Aba Consulta — IE e IM ────────────────────────────────────────────────────
document.getElementById("btnIE").addEventListener("click", () => {
    chrome.tabs.create({
        url: "https://www.cadesp.fazenda.sp.gov.br/(S(uqfpstpjeglrtjcstrzfkrpx))/Pages/Cadastro/Consultas/ConsultaPublica/ConsultaPublica.aspx"
    });
});

document.getElementById("btnIM").addEventListener("click", () => {
    chrome.tabs.create({
        url: "https://www.ribeiraopreto.sp.gov.br/fazenda/consulta-inscricao-municipal"
    });
});

// ── Botão Down NFSE Nacional ──────────────────────────────────────────────────
document.getElementById("btnDownNFSE").addEventListener("click", () => {
    window.location.href = 'nfse-popup.html';
});

// ── Botão Help IA ─────────────────────────────────────────────────────────────
document.getElementById("btnHelpIA").addEventListener("click", () => {
    window.location.href = 'help-ia.html';
});

// ── Acordeão Download ─────────────────────────────────────────────────────────
document.getElementById("btnToggleDownload").addEventListener("click", () => {
    const panel = document.getElementById("downloadPanel");
    const arrow = document.getElementById("downloadArrow");
    const aberto = panel.classList.toggle("aberto");
    arrow.classList.toggle("aberto", aberto);
});

// ══ DOWNLOAD — MOTOR COMPLETO (Nota RP · ISSNet · Portal Nacional · Genérico) ══

async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

async function detectarPortal(tabId) {
  const r = await chrome.scripting.executeScript({ target: { tabId }, func: () => location.href });
  const url = (r?.[0]?.result || "").toLowerCase();
  if (url.includes("notarp.com.br"))       return "notarp";
  if (url.includes("issnetonline.com.br")) return "issnet";
  if (url.includes("nfse.gov.br"))         return "portalnacional";
  return "generico";
}

// Injeta JSZip na aba usando files: (bypassa CSP da página — extensões têm permissão)
// Globals de um executeScript persistem para o próximo no mesmo tab/world
async function injectJsZipNaAba(tabId) {
  // Verifica se já está injetado
  const check = await chrome.scripting.executeScript({
    target: { tabId },
    func: () => typeof JSZip !== "undefined"
  });
  if (check?.[0]?.result === true) return;
  // Injeta via files: — bypassa CSP (extensão tem permissão própria)
  await chrome.scripting.executeScript({
    target: { tabId },
    files: ["jszip_min.js"]
  });
}

// Cria ZIP no sidepanel (JSZip disponível via <script> no HTML)
// Faz fetch dos arquivos diretamente — só funciona se não houver CORS
async function criarZipSidepanel(tarefas, filename, onProg) {
  const zip  = new JSZip();
  const CONC = 4;
  let ok = 0;
  const erros = [];
  for (let i = 0; i < tarefas.length; i += CONC) {
    const lote = tarefas.slice(i, i + CONC);
    const settled = await Promise.allSettled(lote.map(async t => {
      const resp = await fetch(t.url, { credentials: "include" });
      if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
      zip.file(t.nome, await resp.blob());
      ok++;
      if (onProg) onProg(ok, tarefas.length);
    }));
    settled.forEach((r, j) => { if (r.status === "rejected") erros.push(`${lote[j]?.nome}: ${r.reason?.message}`); });
  }
  if (ok === 0) throw new Error("Nenhum arquivo pôde ser baixado.");
  const b64 = await zip.generateAsync({ type: "base64" });
  await chrome.downloads.download({ url: "data:application/zip;base64," + b64, filename, saveAs: false });
  return { ok, total: tarefas.length, erros };
}

// Cria ZIP DENTRO DA ABA — necessário quando há CORS (ex: Portal Nacional)
// JSZip DEVE estar injetado antes via injectJsZipNaAba()
async function criarZipNaAba(tabId, tarefas, filename) {
  await injectJsZipNaAba(tabId);

  const results = await chrome.scripting.executeScript({
    target: { tabId },
    func: async (tarefas) => {
      // JSZip está no escopo global da aba (injetado por injectJsZipNaAba)
      if (typeof JSZip === "undefined") return { erro: "JSZip não disponível mesmo após injeção." };
      const zip  = new JSZip();
      const CONC = 4;
      let ok = 0;
      const erros = [];
      for (let i = 0; i < tarefas.length; i += CONC) {
        const lote = tarefas.slice(i, i + CONC);
        const settled = await Promise.allSettled(lote.map(async t => {
          const resp = await fetch(t.url, { credentials: "include" });
          if (!resp.ok) throw new Error("HTTP " + resp.status);
          zip.file(t.nome, await resp.blob());
          ok++;
        }));
        settled.forEach((r, j) => { if (r.status === "rejected") erros.push((lote[j]?.nome || "?") + ": " + r.reason?.message); });
      }
      if (ok === 0) return { erro: "Nenhum arquivo pôde ser baixado. " + erros.join(" | ") };
      const b64 = await zip.generateAsync({ type: "base64" });
      return { zipBase64: b64, ok, total: tarefas.length, erros };
    },
    args: [tarefas]
  });

  const res = results?.[0]?.result;
  if (!res || res.erro) throw new Error(res?.erro || "Erro ao criar ZIP na aba.");
  await chrome.downloads.download({ url: "data:application/zip;base64," + res.zipBase64, filename, saveAs: false });
  return res;
}

// ══════════════════════════════════════════════════════════════════════════════
//  NOTA RP (notarp.com.br)
//  Links ficam em popover/dropdown que abre ao clicar nos "..." de cada linha.
//  Os hrefs reais são: /nota/pdf/{id} e /nota/xml/{id} (mesmo domínio).
//  Estratégia: coletar TODOS os <a href> do domínio que contenham pdf ou xml,
//  excluindo explicitamente URLs conhecidas de conteúdo estático/contrato.
// ══════════════════════════════════════════════════════════════════════════════
// ══════════════════════════════════════════════════════════════════════════════
//  NOTA RP (notarp.com.br)
//  URLs confirmadas: /painel/pdf/{id}/download?id_empresa=N
//                    /painel/xml/{id}/download?id_empresa=N
//  Fetch no sidepanel (mesmo domínio, sem CORS)
// ══════════════════════════════════════════════════════════════════════════════
async function downloadNotaRP(tabId, tipos, filename, onProg) {
  const r = await chrome.scripting.executeScript({
    target: { tabId },
    func: (tipos) => {
      const links  = [];
      const vistos = new Set();
      for (const a of document.querySelectorAll("a[href]")) {
        let url;
        try { url = new URL(a.getAttribute("href") || "", location.origin).href; } catch (_) { continue; }
        const low = url.toLowerCase();
        // Exclui documentos estáticos conhecidos
        if (low.includes("contrato") || low.includes("termos") || low.includes("politica") || low.includes("manual")) continue;
        // Detecta pelo padrão exato do Nota RP
        let tipo = null;
        if (tipos.includes("pdf") && low.includes("/painel/pdf/")) tipo = "pdf";
        if (tipos.includes("xml") && low.includes("/painel/xml/")) tipo = "xml";
        if (tipo && !vistos.has(url)) { vistos.add(url); links.push({ url, tipo }); }
      }
      return links;
    },
    args: [tipos]
  });

  const links = r?.[0]?.result || [];
  if (links.length === 0) throw new Error("Nota RP: nenhum link /painel/pdf/ ou /painel/xml/ encontrado na página.");

  const cont    = {};
  const tarefas = links.map(lk => {
    const ext = lk.tipo; cont[ext] = (cont[ext] || 0) + 1;
    return { url: lk.url, nome: ext.toUpperCase() + "/nota_" + String(cont[ext]).padStart(4, "0") + "." + ext };
  });

  return criarZipSidepanel(tarefas, filename, onProg);
}

// ══════════════════════════════════════════════════════════════════════════════
//  PORTAL NACIONAL (nfse.gov.br)
//  CORS bloqueia fetch do sidepanel → tudo roda DENTRO da aba
//  JSZip injetado com files: (bypassa CSP)
//  Seletores: a[href*="Download/NFSe"] (XML), a[href*="Download/DANFSe"] (PDF)
// ══════════════════════════════════════════════════════════════════════════════
async function downloadPortalNacional(tabId, tipos, filename) {
  // Injeta JSZip com files: (bypassa CSP — extensão tem permissão própria)
  await injectJsZipNaAba(tabId);

  const results = await chrome.scripting.executeScript({
    target: { tabId },
    func: async (tipos) => {
      if (typeof JSZip === "undefined") return { erro: "JSZip não disponível." };

      const ORIGIN    = "https://www.nfse.gov.br";
      const MAX_PAGES = 500;
      const CONC      = 4;

      // Detecta base URL e datas da página atual
      const cur  = new URL(location.href);
      const base = location.href.toLowerCase().includes("recebidas")
        ? ORIGIN + "/EmissorNacional/Notas/Recebidas"
        : ORIGIN + "/EmissorNacional/Notas/Emitidas";

      let di = cur.searchParams.get("datainicio") || "";
      let df = cur.searchParams.get("datafim")    || "";

      // Tenta ler dos inputs da página se não estiver na URL
      if (!di || !df) {
        const elDi = document.querySelector('input[name*="datainicio"],input[id*="datainicio"]');
        const elDf = document.querySelector('input[name*="datafim"],input[id*="datafim"]');
        if (elDi) di = elDi.value;
        if (elDf) df = elDf.value;
      }
      // Fallback: 30 dias
      if (!di || !df) {
        const hoje = new Date();
        const mes  = new Date(hoje); mes.setDate(hoje.getDate() - 30);
        const fmt  = d => d.toLocaleDateString("pt-BR").replace(/\//g, "-");
        di = fmt(mes); df = fmt(hoje);
      }

      // Coleta links de todas as páginas
      const allLinks = [];
      for (let pg = 1; pg <= MAX_PAGES; pg++) {
        const url = base + "?pg=" + pg + "&executar=1&busca=&datainicio=" + di + "&datafim=" + df;
        let html  = "";
        try {
          const resp = await fetch(url, { credentials: "include", redirect: "follow" });
          if (!resp.ok) break;
          html = await resp.text();
        } catch (_) { break; }

        const low = html.toLowerCase();
        if ((low.includes('action="/emissornacional/login"') || low.includes("realize o login")) && !low.includes("download/nfse")) {
          return { erro: "Sessão expirada. Faça login no Portal Nacional NFS-e." };
        }

        const doc  = new DOMParser().parseFromString(html, "text/html");
        const rows = doc.querySelectorAll("table.table.table-striped tbody tr");
        if (rows.length === 0 && pg > 1) break;

        rows.forEach(row => {
          const xmlA = row.querySelector('a[href*="Download/NFSe"]');
          const pdfA = row.querySelector('a[href*="Download/DANFSe"]');
          if (tipos.includes("xml") && xmlA) {
            try { allLinks.push({ url: new URL(xmlA.getAttribute("href"), ORIGIN).href, tipo: "xml" }); } catch (_) {}
          }
          if (tipos.includes("pdf") && pdfA) {
            try { allLinks.push({ url: new URL(pdfA.getAttribute("href"), ORIGIN).href, tipo: "pdf" }); } catch (_) {}
          }
        });

        const nextA  = doc.querySelector("a[rel=next]");
        const actLi  = doc.querySelector(".pagination li.active");
        const nextLi = actLi && actLi.nextElementSibling;
        const hasNext = (nextA && !nextA.classList.contains("disabled")) ||
                        (nextLi && nextLi.querySelector("a") && !nextLi.querySelector("a").classList.contains("disabled"));
        if (!hasNext) break;
      }

      if (allLinks.length === 0) {
        return { erro: "Portal Nacional: nenhuma nota encontrada. Datas: " + di + " a " + df + ". Verifique se há notas no período." };
      }

      // Cria ZIP dentro da aba (JSZip já injetado, disponível no escopo global)
      const zip  = new JSZip();
      const cont = {};
      let ok = 0;

      for (let i = 0; i < allLinks.length; i += CONC) {
        const lote = allLinks.slice(i, i + CONC);
        await Promise.allSettled(lote.map(async lk => {
          const resp = await fetch(lk.url, { credentials: "include" });
          if (!resp.ok) return;
          const blob = await resp.blob();
          const ext  = lk.tipo;
          cont[ext]  = (cont[ext] || 0) + 1;
          zip.file(ext.toUpperCase() + "/nota_" + String(cont[ext]).padStart(4, "0") + "." + ext, blob);
          ok++;
        }));
      }

      if (ok === 0) return { erro: "Portal Nacional: nenhum arquivo pôde ser baixado." };
      const b64 = await zip.generateAsync({ type: "base64" });
      return { zipBase64: b64, ok, total: allLinks.length };
    },
    args: [tipos]
  });

  const res = results?.[0]?.result;
  if (!res || res.erro) throw new Error(res?.erro || "Erro no Portal Nacional.");
  await chrome.downloads.download({ url: "data:application/zip;base64," + res.zipBase64, filename, saveAs: false });
  return res;
}

// ══════════════════════════════════════════════════════════════════════════════
//  ISSNET ONLINE (issnetonline.com.br)
//  Botões em tr.HeaderStyleNovo — href="javascript:__doPostBack(...)"
//  JSZip injetado com files: (bypassa CSP)
// ══════════════════════════════════════════════════════════════════════════════
async function downloadIssnet(tabId, tipos, filename) {
  await injectJsZipNaAba(tabId);

  const results = await chrome.scripting.executeScript({
    target: { tabId },
    func: async (tipos) => {
      if (typeof JSZip === "undefined") return { erro: "JSZip não disponível." };

      // Busca botões em QUALQUER <a> da página (incluindo thead/HeaderStyleNovo)
      const botoes = [];
      for (const a of document.querySelectorAll("a")) {
        const id      = a.id || "";
        const rawHref = a.getAttribute("href") || "";
        const onclick = a.getAttribute("onclick") || "";
        const combined = id + "|" + rawHref + "|" + onclick;

        if (tipos.includes("xml") && combined.includes("btnExportarTodosXml") && !botoes.find(b => b.tipo === "xml")) {
          botoes.push({ tipo: "xml", id, rawHref, onclick });
        }
        if (tipos.includes("pdf") && combined.includes("btnGerarNotasPdf") && !botoes.find(b => b.tipo === "pdf")) {
          botoes.push({ tipo: "pdf", id, rawHref, onclick });
        }
      }

      if (botoes.length === 0) {
        const debug = Array.from(document.querySelectorAll("a"))
          .filter(a => (a.getAttribute("href") || "").includes("doPostBack") || (a.getAttribute("onclick") || "").includes("doPostBack"))
          .slice(0, 5)
          .map(a => "id=" + a.id + "|href=" + (a.getAttribute("href") || "").substring(0, 80))
          .join(" / ") || "nenhum link doPostBack encontrado";
        return { erro: "ISSNet: botões de download não encontrados. Links doPostBack na página: " + debug };
      }

      // Coleta campos hidden do formulário ASP.NET
      const form = document.getElementById("aspnetForm") || document.querySelector("form");
      if (!form) return { erro: "ISSNet: formulário ASP.NET não encontrado." };

      const formAction = form.action || location.href;
      const camposBase = {};
      for (const el of form.querySelectorAll("input[type=hidden]")) {
        if (el.name) camposBase[el.name] = el.value;
      }

      const zip  = new JSZip();
      let ok = 0;
      const erros = [];

      for (const btn of botoes) {
        // Extrai __EVENTTARGET e __EVENTARGUMENT do href ou onclick
        const src   = btn.rawHref + "|" + btn.onclick;
        const match = src.match(/__doPostBack\('([^']+)','([^']*)'\)/);
        if (!match) { erros.push(btn.tipo + ": __doPostBack não encontrado em: " + src.substring(0, 100)); continue; }

        const body = new URLSearchParams(Object.assign({}, camposBase, {
          __EVENTTARGET:   match[1],
          __EVENTARGUMENT: match[2]
        }));

        try {
          const resp = await fetch(formAction, {
            method:      "POST",
            credentials: "include",
            headers:     { "Content-Type": "application/x-www-form-urlencoded" },
            body:         body.toString()
          });
          if (!resp.ok) { erros.push(btn.tipo + ": HTTP " + resp.status); continue; }
          const ct = (resp.headers.get("content-type") || "").toLowerCase();
          if (ct.includes("text/html")) { erros.push(btn.tipo + ": servidor retornou HTML — verifique o período selecionado."); continue; }
          const blob = await resp.blob();
          const ext  = btn.tipo;
          const nome = ct.includes("zip")
            ? ext.toUpperCase() + "/notas_issnet_" + ext + ".zip"
            : ext.toUpperCase() + "/notas_issnet_" + ext + "." + ext;
          zip.file(nome, blob);
          ok++;
        } catch (e) { erros.push(btn.tipo + ": " + e.message); }
      }

      if (ok === 0) return { erro: "ISSNet: nenhum arquivo baixado. " + erros.join(" | ") };
      const b64 = await zip.generateAsync({ type: "base64" });
      return { zipBase64: b64, ok, total: botoes.length, erros };
    },
    args: [tipos]
  });

  const res = results?.[0]?.result;
  if (!res || res.erro) throw new Error(res?.erro || "Erro no ISSNet.");
  await chrome.downloads.download({ url: "data:application/zip;base64," + res.zipBase64, filename, saveAs: false });
  return res;
}

// ── Genérico (fallback) ───────────────────────────────────────────────────────
async function downloadGenerico(tabId, tipos, filename, onProg) {
  const r = await chrome.scripting.executeScript({
    target: { tabId },
    func: (tipos) => {
      const dominio = location.hostname;
      const vistos  = new Set();
      const links   = [];
      for (const a of document.querySelectorAll("a[href]")) {
        const raw = a.getAttribute("href") || "";
        if (!raw || raw.startsWith("javascript:") || raw === "#") continue;
        let url;
        try { url = new URL(raw, location.origin).href; } catch (_) { continue; }
        if (new URL(url).hostname !== dominio) continue;
        const low   = url.toLowerCase();
        const title = (a.getAttribute("data-original-title") || a.title || "").toLowerCase();
        let tipo = null;
        if (tipos.includes("pdf") && (low.includes(".pdf") || title.includes("pdf") || low.includes("danfe"))) tipo = "pdf";
        if (tipos.includes("xml") && !tipo && (low.includes(".xml") || title.includes("xml"))) tipo = "xml";
        if (tipo && !vistos.has(url)) { vistos.add(url); links.push({ url, tipo }); }
      }
      return links;
    },
    args: [tipos]
  });
  const links = r?.[0]?.result || [];
  if (links.length === 0) throw new Error("Nenhum link encontrado na página.");
  const cont = {};
  const tarefas = links.map(lk => {
    const ext = lk.tipo; cont[ext] = (cont[ext] || 0) + 1;
    let nome;
    try {
      const seg = decodeURIComponent(new URL(lk.url).pathname.split("/").pop());
      nome = seg && seg.includes(".") ? `${ext.toUpperCase()}/${seg}` : `${ext.toUpperCase()}/nota_${String(cont[ext]).padStart(4,"0")}.${ext}`;
    } catch (_) { nome = `${ext.toUpperCase()}/nota_${String(cont[ext]).padStart(4,"0")}.${ext}`; }
    return { url: lk.url, nome };
  });
  return criarZipSidepanel(tarefas, filename, onProg);
}

// ── Orquestrador ──────────────────────────────────────────────────────────────
async function executarDownload(tipos) {
  const statusDl   = document.getElementById("statusDl");
  const dlProgress = document.getElementById("dlProgress");
  const dlMsg      = document.getElementById("dlMsg");
  const dlBar      = document.getElementById("dlBar");
  const btnPdf     = document.getElementById("btnBaixarPdf");
  const btnXml     = document.getElementById("btnBaixarXml");
  const btnTudo    = document.getElementById("btnBaixarTudo");

  btnPdf.disabled = btnXml.disabled = btnTudo.disabled = true;
  statusDl.className = "status info";
  dlProgress.classList.add("show");
  dlBar.style.width = "5%";

  const setStatus = (msg, cls = "info") => {
    statusDl.className = `status ${cls}`;
    statusDl.textContent = msg;
  };

  try {
    if (typeof JSZip === "undefined") throw new Error("JSZip não carregado. Verifique se jszip_min.js está na pasta e no sidepanel.html.");

    const tab    = await getActiveTab();
    const portal = await detectarPortal(tab.id);
    const nomes  = { notarp: "Nota RP", issnet: "ISSNet", portalnacional: "Portal Nacional", generico: "Portal" };
    setStatus(`${nomes[portal]}: processando...`);
    dlMsg.textContent = "Aguarde...";
    dlBar.style.width = "15%";

    const agora  = new Date();
    const ts     = `${agora.getFullYear()}${String(agora.getMonth()+1).padStart(2,"0")}${String(agora.getDate()).padStart(2,"0")}_${String(agora.getHours()).padStart(2,"0")}${String(agora.getMinutes()).padStart(2,"0")}`;
    const nome   = `notas_${tipos.join("_").toUpperCase()}_${ts}.zip`;

    let res;

    if (portal === "notarp") {
      res = await downloadNotaRP(tab.id, tipos, nome, (ok, tot) => {
        dlBar.style.width = `${15 + (ok/tot)*80}%`;
        dlMsg.textContent = `${ok}/${tot} arquivos`;
      });

    } else if (portal === "portalnacional") {
      setStatus("Portal Nacional: coletando e baixando (pode demorar)...");
      res = await downloadPortalNacional(tab.id, tipos, nome);

    } else if (portal === "issnet") {
      setStatus("ISSNet: fazendo POST e baixando...");
      res = await downloadIssnet(tab.id, tipos, nome);

    } else {
      res = await downloadGenerico(tab.id, tipos, nome, (ok, tot) => {
        dlBar.style.width = `${15 + (ok/tot)*80}%`;
        dlMsg.textContent = `${ok}/${tot} arquivos`;
      });
    }

    dlBar.style.width = "100%";
    const extras = res.erros?.length ? ` (${res.erros.length} erro(s))` : "";
    setStatus(`✔ ${res.ok ?? res.baixados} arquivo(s) → ${nome}${extras}`, "ok");
    dlMsg.textContent = "Concluído!";
    if (res.erros?.length) console.warn("[Download] Erros:", res.erros);
    setTimeout(() => { dlProgress.classList.remove("show"); dlBar.style.width = "0%"; }, 4000);

  } catch (err) {
    setStatus("Erro: " + err.message, "erro");
    dlProgress.classList.remove("show");
    console.error("[Download]", err);
  }

  btnPdf.disabled = btnXml.disabled = btnTudo.disabled = false;
}

document.getElementById("btnBaixarPdf").addEventListener("click",  () => executarDownload(["pdf"]));
document.getElementById("btnBaixarXml").addEventListener("click",  () => executarDownload(["xml"]));
document.getElementById("btnBaixarTudo").addEventListener("click", () => executarDownload(["pdf", "xml"]));

// ── Calcular ──────────────────────────────────────────────────────────────────
document.getElementById("calcular").addEventListener("click", async () => {
    const input  = document.getElementById("valor").value;
    const numero = parseFloat(input.replace(/\D/g, "")) / 100;
    const resultado = document.getElementById("resultado");

    if (isNaN(numero) || numero <= 0) {
        resultado.innerHTML = `<div class="card" style="color:#b91c1c;font-size:13px;text-align:center;">Informe um valor válido.</div>`;
        return;
    }

    const ali = await carregarAliquotas();
    const pis    = numero * (ali.pis    / 100);
    const cofins = numero * (ali.cofins / 100);
    const irrf   = numero * (ali.irrf   / 100);
    const csll   = numero * (ali.csll   / 100);

    const somaPcc    = pis + cofins + csll;
    const exibirPcc  = somaPcc >= 10;
    const exibirIrrf = irrf >= 10;

    const impostos = [
        { nome: "PIS",    valor: pis,    ok: exibirPcc },
        { nome: "COFINS", valor: cofins, ok: exibirPcc },
        { nome: "CSLL",   valor: csll,   ok: exibirPcc },
        { nome: "IRRF",   valor: irrf,   ok: exibirIrrf },
    ].filter(i => i.ok);

    if (impostos.length === 0) {
        resultado.innerHTML = `<div class="card" style="font-size:13px;color:#64748b;text-align:center;padding:12px;">Nenhum imposto a reter<br><small>(todos abaixo de R$ 10,00)</small></div>`;
        return;
    }

    const totalImpostos = impostos.reduce((s, i) => s + i.valor, 0);
    const valorLiquido  = numero - totalImpostos;

    const card = document.createElement("div");
    card.className = "card";

    const hint = document.createElement("div");
    hint.className = "copy-hint";
    hint.textContent = "Clique em qualquer linha para copiar o valor";
    card.appendChild(hint);

    impostos.forEach(imp => {
        const linha = document.createElement("div");
        linha.className = "imposto-linha";
        linha.innerHTML = `<span class="imposto-nome">${imp.nome}</span><span class="imposto-valor">${formatarMoeda(imp.valor)}</span>`;
        linha.addEventListener("click", () => copiarValor(imp.valor, linha));
        card.appendChild(linha);
    });

    const totalEl = document.createElement("div");
    totalEl.className = "total-linha";
    totalEl.innerHTML = `<span>Líquido</span><span>${formatarMoeda(valorLiquido)}</span>`;
    totalEl.addEventListener("click", async () => {
        try { await navigator.clipboard.writeText(formatarNumero(valorLiquido)); } catch (_) {}
        const span = totalEl.querySelector("span");
        const bkp = span.textContent;
        span.textContent = "✔ Copiado!";
        setTimeout(() => span.textContent = bkp, 800);
    });
    card.appendChild(totalEl);

    resultado.innerHTML = "";
    resultado.appendChild(card);
});

// ── Config ────────────────────────────────────────────────────────────────────
async function inicializarConfig() {
    const ali = await carregarAliquotas();
    document.getElementById("cfg-pis").value    = ali.pis;
    document.getElementById("cfg-cofins").value = ali.cofins;
    document.getElementById("cfg-csll").value   = ali.csll;
    document.getElementById("cfg-irrf").value   = ali.irrf;
    atualizarBadges(ali);
    carregarLicencaConfig(); // carrega dados da licença na aba config
}

function atualizarBadges(ali) {
    document.getElementById("badge-pis").textContent    = ali.pis.toFixed(2).replace(".", ",") + "%";
    document.getElementById("badge-cofins").textContent = ali.cofins.toFixed(2).replace(".", ",") + "%";
    document.getElementById("badge-csll").textContent   = ali.csll.toFixed(2).replace(".", ",") + "%";
    document.getElementById("badge-irrf").textContent   = ali.irrf.toFixed(2).replace(".", ",") + "%";
}

document.getElementById("salvarConfig").addEventListener("click", async () => {
    const ali = {
        pis:    parseFloat(document.getElementById("cfg-pis").value)    || DEFAULTS.pis,
        cofins: parseFloat(document.getElementById("cfg-cofins").value) || DEFAULTS.cofins,
        csll:   parseFloat(document.getElementById("cfg-csll").value)   || DEFAULTS.csll,
        irrf:   parseFloat(document.getElementById("cfg-irrf").value)   || DEFAULTS.irrf,
    };
    await chrome.storage.local.set({ aliquotas: ali });
    atualizarBadges(ali);
    const msg = document.getElementById("saveMsg");
    msg.classList.add("show");
    setTimeout(() => msg.classList.remove("show"), 2500);
});

document.getElementById("resetarConfig").addEventListener("click", async () => {
    await chrome.storage.local.remove("aliquotas");
    document.getElementById("cfg-pis").value    = DEFAULTS.pis;
    document.getElementById("cfg-cofins").value = DEFAULTS.cofins;
    document.getElementById("cfg-csll").value   = DEFAULTS.csll;
    document.getElementById("cfg-irrf").value   = DEFAULTS.irrf;
    atualizarBadges(DEFAULTS);
    const msg = document.getElementById("saveMsg");
    msg.textContent = "✔ Padrões restaurados!";
    msg.classList.add("show");
    setTimeout(() => { msg.classList.remove("show"); msg.textContent = "✔ Configurações salvas!"; }, 2500);
});

// ── Licença na Config ─────────────────────────────────────────────────────────

// Formata chave enquanto digita
const cfgLicChave = document.getElementById("cfg-lic-chave");
if (cfgLicChave) {
    cfgLicChave.addEventListener("input", function () {
        let v = this.value.toUpperCase().replace(/[^A-Z0-9]/g, '');
        if (v.startsWith('FISCAL')) {
            const prefixo = v.substring(0, 6);
            const resto = v.substring(6).replace(/(.{4})/g, '$1-').replace(/-$/, '');
            this.value = resto ? prefixo + '-' + resto : prefixo;
        }
    });
}

// Carrega dados da licença na aba config
function carregarLicencaConfig() {
    chrome.runtime.sendMessage({ action: 'getLicenseInfo' }, (result) => {
        if (chrome.runtime.lastError) return;
        if (!result) return;

        const infoBox  = document.getElementById("licInfoBox");
        const elStatus = document.getElementById("licStatus");
        const elPlano  = document.getElementById("licPlano");
        const elExpira = document.getElementById("licExpira");
        const elExpWrap = document.getElementById("licExpiraWrap");
        const inputChave = document.getElementById("cfg-lic-chave");
        const inputEmail = document.getElementById("cfg-lic-email");

        if (result.chave) inputChave.value = result.chave;
        if (result.email) inputEmail.value = result.email;

        if (result.ok) {
            infoBox.style.display = 'block';
            elStatus.textContent = '✅ Ativa';
            elStatus.style.color = '#15803d';
            elPlano.textContent = result.plano || 'ATIVO';
            if (result.diasRestantes != null) {
                elExpWrap.style.display = '';
                elExpira.textContent = result.diasRestantes + ' dia(s) — ' + (result.expira || '');
                if (result.diasRestantes <= 7) elExpira.style.color = '#dc2626';
            } else {
                elExpWrap.style.display = '';
                elExpira.textContent = 'Sem expiração';
            }
        } else if (result.chave) {
            infoBox.style.display = 'block';
            elStatus.textContent = '❌ Inválida';
            elStatus.style.color = '#dc2626';
            elPlano.textContent = '—';
            elExpWrap.style.display = 'none';
        }
    });
}

// Salvar licença pela config
document.getElementById("salvarLicenca").addEventListener("click", async () => {
    const chave = document.getElementById("cfg-lic-chave").value.trim();
    const email = document.getElementById("cfg-lic-email").value.trim();
    const msgEl = document.getElementById("saveMsgLic");

    if (!chave || !email) {
        msgEl.textContent = "❌ Preencha chave e e-mail!";
        msgEl.style.color = "#dc2626";
        msgEl.classList.add("show");
        setTimeout(() => { msgEl.classList.remove("show"); msgEl.style.color = "#15803d"; msgEl.textContent = "✔ Licença salva!"; }, 3000);
        return;
    }

    const btnSalvar = document.getElementById("salvarLicenca");
    btnSalvar.disabled = true;
    btnSalvar.textContent = "Verificando...";

    chrome.runtime.sendMessage({ action: 'salvarLicenca', chave, email }, (result) => {
        btnSalvar.disabled = false;
        btnSalvar.textContent = "Salvar Licença";

        if (chrome.runtime.lastError) {
            msgEl.textContent = "❌ Erro de comunicação";
            msgEl.style.color = "#dc2626";
        } else if (result && result.ok) {
            msgEl.textContent = "✔ Licença salva e verificada!";
            msgEl.style.color = "#15803d";
            carregarLicencaConfig(); // atualiza os dados exibidos
        } else {
            msgEl.textContent = "❌ " + (result?.msg || "Licença inválida");
            msgEl.style.color = "#dc2626";
        }

        msgEl.classList.add("show");
        setTimeout(() => { msgEl.classList.remove("show"); msgEl.style.color = "#15803d"; msgEl.textContent = "✔ Licença salva!"; }, 3500);
    });
});
