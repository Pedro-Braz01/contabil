// help-ia.js — Fiscal 5
document.addEventListener('DOMContentLoaded', function () {

  const NOTEBOOK_URL = 'https://notebooklm.google.com/notebook/9dce538e-b612-44fa-a841-d93b5c21af9b/preview';

  // Abre o NotebookLM imediatamente ao carregar a página
  chrome.tabs.create({ url: NOTEBOOK_URL });

  // Botão Voltar
  document.getElementById('btnVoltarHelpIA').addEventListener('click', function () {
    window.location.href = chrome.runtime.getURL('sidepanel.html');
  });

  // Botão Abrir (caso o usuário queira abrir novamente)
  document.getElementById('btnAbrirNotebook').addEventListener('click', function () {
    chrome.tabs.create({ url: NOTEBOOK_URL });
  });

});
