// Fiscal 5 — Pbs Dev
// Copyright (c) 2018-2026 Pbs Dev
// Todos os direitos reservados. Código protegido.
/* eslint-disable */

document.addEventListener('DOMContentLoaded', function () {

  const NOTEBOOK_URL = 'https:

  
  chrome.tabs.create({ url: NOTEBOOK_URL });

  
  document.getElementById('btnVoltarHelpIA').addEventListener('click', function () {
    window.location.href = chrome.runtime.getURL('sidepanel.html');
  });

  
  document.getElementById('btnAbrirNotebook').addEventListener('click', function () {
    chrome.tabs.create({ url: NOTEBOOK_URL });
  });

});
