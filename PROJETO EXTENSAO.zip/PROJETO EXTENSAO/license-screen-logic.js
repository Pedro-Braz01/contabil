// Remova a tag <script> do início e a tag </script> do final

(async () => {
  const btnAtivar   = document.getElementById('btnAtivar');
  const inputChave  = document.getElementById('inputChave');
  const inputEmail  = document.getElementById('inputEmail');
  const msgBox      = document.getElementById('msgBox');
  const telaAtivacao= document.getElementById('telaAtivacao');
  const telaAtiva   = document.getElementById('telaAtiva');

  function showMsg(tipo, texto) {
    msgBox.className = 'msg-box ' + tipo;
    msgBox.textContent = texto;
    msgBox.style.display = 'block';
  }

  function setLoading(loading) {
    btnAtivar.disabled = loading;
    btnAtivar.innerHTML = loading
      ? '<span class="loading-spin"></span>Verificando...'
      : 'Ativar Licença';
  }

  // Formata chave enquanto digita
  inputChave.addEventListener('input', function () {
    let v = this.value.toUpperCase().replace(/[^A-Z0-9]/g, '');
    // Divide em grupos de 4 com hífen depois do prefixo "FISCAL"
    // Formato: FISCAL-XXXX-XXXX-XXXX
    if (v.startsWith('FISCAL')) {
      const prefixo = v.substring(0, 6);
      const resto = v.substring(6).replace(/(.{4})/g, '$1-').replace(/-$/, '');
      this.value = resto ? prefixo + '-' + resto : prefixo;
    }
  });

  // Verifica se já tem licença ativa
  const resultado = await LICENSE.verificar();
  if (resultado.ok) {
    const creds = await LICENSE.carregarCredenciais();
    exibirLicencaAtiva(resultado, creds.email);
    return;
  }

  // Botão ativar
  btnAtivar.addEventListener('click', async () => {
    const chave = inputChave.value.trim();
    const email = inputEmail.value.trim();

    inputChave.classList.remove('erro');
    inputEmail.classList.remove('erro');
    msgBox.style.display = 'none';

    if (!chave) { inputChave.classList.add('erro'); showMsg('erro', 'Informe a chave de licença.'); return; }
    if (!email) { inputEmail.classList.add('erro'); showMsg('erro', 'Informe o e-mail.'); return; }

    setLoading(true);
    showMsg('info', 'Verificando licença...');

    const result = await LICENSE.ativar(chave, email);
    setLoading(false);

    if (result.ok) {
      showMsg('ok', '✅ ' + result.msg);
      setTimeout(async () => {
        const verificacao = await LICENSE.verificar(true);
        exibirLicencaAtiva(verificacao, email);
      }, 1200);
    } else {
      showMsg('erro', '❌ ' + result.msg);
    }
  });

  function exibirLicencaAtiva(dados, email) {
    telaAtivacao.style.display = 'none';
    telaAtiva.style.display   = 'block';

    document.getElementById('planoBadge').textContent = dados.plano || 'ATIVO';
    document.getElementById('infoEmail').textContent  = email || dados.email || '—';

    const infoDias = document.getElementById('infoDias');
    if (dados.diasRestantes != null) {
      infoDias.innerHTML = `Expira em <strong>${dados.diasRestantes} dia(s)</strong> — ${dados.expira}`;
      if (dados.diasRestantes <= 7) infoDias.style.color = '#dc2626';
    } else {
      infoDias.textContent = 'Sem data de expiração';
    }
  }

  document.getElementById('btnSair').addEventListener('click', async () => {
    if (confirm('Deseja realmente desativar a licença neste dispositivo?')) {
      await LICENSE.limparCredenciais();
      telaAtiva.style.display   = 'none';
      telaAtivacao.style.display = 'block';
      inputChave.value = '';
      inputEmail.value = '';
      msgBox.style.display = 'none';
    }
  });
})();